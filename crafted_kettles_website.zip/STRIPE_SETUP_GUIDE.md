
# Crafted Kettles - Stripe Payment Integration Setup Guide

## 🎯 Complete Features Implemented

✅ **Shopping Cart System**
- Add/remove/update items
- Persistent cart storage (localStorage + database)
- Multi-currency support (GBP, USD, EUR)
- Free UK shipping, £14.99 international shipping

✅ **Stripe Payment Processing**
- Secure payment intent creation
- Multi-currency checkout (GBP default)
- International shipping calculation
- 20% VAT for UK addresses
- Real-time payment confirmation

✅ **Order Management**
- Complete order storage in database
- Order status tracking (Pending → Confirmed → Processing → Shipped → Delivered)
- Payment status tracking (Pending → Paid/Failed)
- Order confirmation emails
- Order history for users

✅ **User Account System**
- User registration and authentication
- Account dashboard with order history
- Guest checkout option available
- Order lookup for guest users

✅ **Post-Purchase Experience**
- Custom thank you page
- Order confirmation emails (configurable SMTP)
- Order tracking and status updates
- Webhook integration for real-time updates

## 🔧 Stripe Account Setup

### Step 1: Create/Access Your Stripe Account
1. Go to [stripe.com](https://stripe.com) and create an account or sign in
2. Navigate to Dashboard → Settings → API keys
3. Copy your **Test Mode** keys (we'll use these first)

### Step 2: Get Your Stripe Keys
```bash
# Test Mode Keys (start with these)
Publishable key: pk_test_...
Secret key: sk_test_...
```

### Step 3: Configure Webhook Endpoint
1. Go to Dashboard → Developers → Webhooks
2. Click "Add endpoint"
3. URL: `https://your-domain.com/api/webhooks/stripe`
4. Select these events:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
5. Copy the webhook signing secret: `whsec_...`

## 🛠️ Environment Setup

### Update your `.env` file:
```bash
# Database (already configured)
DATABASE_URL="your_existing_postgres_url"

# NextAuth (already configured)
NEXTAUTH_SECRET="your_existing_secret"
NEXTAUTH_URL="http://localhost:3000"

# Stripe Configuration - REPLACE WITH YOUR ACTUAL KEYS
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_test_your_actual_publishable_key"
STRIPE_SECRET_KEY="sk_test_your_actual_secret_key"
STRIPE_WEBHOOK_SECRET="whsec_your_actual_webhook_secret"

# Email Configuration (Optional - for order confirmations)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_SECURE="false"
SMTP_USER="your_email@gmail.com"
SMTP_PASSWORD="your_app_password"
SMTP_FROM="orders@craftedkettles.com"
```

## 📧 Email Setup (Optional but Recommended)

### Option 1: Gmail SMTP
1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password: Google Account → Security → App passwords
3. Use these settings:
   ```
   SMTP_HOST="smtp.gmail.com"
   SMTP_PORT="587"
   SMTP_USER="your_email@gmail.com"
   SMTP_PASSWORD="your_16_character_app_password"
   ```

### Option 2: Professional Email Service
- **SendGrid**: More reliable for production
- **Mailgun**: Good for transactional emails
- **Amazon SES**: Cost-effective for high volume

## 🧪 Testing the Integration

### Test Payment Flow:
1. Add items to cart → `/cart`
2. Proceed to checkout → `/checkout`  
3. Fill in customer details
4. Use Stripe test card: `4242 4242 4242 4242`
   - Any future expiry date
   - Any 3-digit CVC
   - Any postal code
5. Complete payment
6. Verify order confirmation → `/thank-you`

### Test User Account:
- **Pre-seeded Account**: `john@doe.com` / `johndoe123`
- View order history → `/account`
- Test guest checkout (without signing in)

### Test Cards for Different Scenarios:
```bash
# Successful payment
4242 4242 4242 4242

# Declined payment  
4000 0000 0000 0002

# Insufficient funds
4000 0000 0000 9995

# 3D Secure required
4000 0000 0000 3220
```

## 🚀 Going Live (Production)

### Step 1: Activate Your Stripe Account
1. Complete business verification in Stripe Dashboard
2. Provide required business information
3. Wait for account approval

### Step 2: Update Environment Variables
```bash
# Replace test keys with live keys
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_SECRET_KEY="sk_live_..."

# Update webhook endpoint to production URL
STRIPE_WEBHOOK_SECRET="whsec_live_..."

# Update NEXTAUTH_URL to your domain
NEXTAUTH_URL="https://your-domain.com"
```

### Step 3: Configure Production Webhook
1. Create new webhook endpoint in Stripe Dashboard
2. URL: `https://your-domain.com/api/webhooks/stripe`
3. Same events: `payment_intent.succeeded`, `payment_intent.payment_failed`

## 🔍 Key Features Usage

### Multi-Currency Support
- Automatic currency detection based on user location
- Manual currency selector in header
- Proper currency conversion and formatting
- International shipping cost calculation

### Order Management
- Orders stored with complete customer and product details
- Real-time status updates via Stripe webhooks
- Email confirmations sent automatically
- Order lookup for both users and guests

### Security Features
- All payments processed securely through Stripe
- No card details stored on your servers
- CSRF protection on all forms
- Webhook signature verification

## 🐛 Troubleshooting

### Common Issues:

**Payment Intent Creation Fails:**
- Check Stripe secret key is correct
- Verify products exist and are in stock
- Check database connection

**Webhook Not Working:**
- Verify webhook URL is accessible
- Check webhook secret matches
- Review server logs for errors

**Email Not Sending:**
- Verify SMTP configuration
- Check firewall/port restrictions
- Test with simple email service first

### Test Commands:
```bash
# Test database connection
yarn prisma db push

# Test email configuration (if configured)
yarn dev
# Navigate to /test-email (you can create this route for testing)

# Verify Stripe keys
curl -u sk_test_your_key: https://api.stripe.com/v1/payment_intents/pi_test_123
```

## 📊 Analytics & Monitoring

### Track Key Metrics:
- Conversion rate (cart to purchase)
- Average order value
- Payment success rate
- International vs domestic sales

### Recommended Tools:
- Stripe Dashboard for payment analytics  
- Google Analytics for user behavior
- Error logging service (Sentry, LogRocket)

---

## 🎉 You're All Set!

Your Crafted Kettles e-commerce site now has:
- Complete shopping cart and checkout flow
- Secure Stripe payment processing
- User account system with order history
- Multi-currency support
- Order confirmation emails
- Guest checkout option
- Mobile-responsive luxury design

Test thoroughly in development, then update your environment variables and go live!
