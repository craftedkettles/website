
export const metadata = {
  title: 'Policies | Crafted Kettles',
  description: 'Our shipping, returns, warranty, and privacy policies for luxury watch purchases.',
}

export default function PoliciesPage() {
  const policies = [
    {
      title: 'Shipping Policy',
      content: `
        <h3>Delivery Times</h3>
        <p>UK Standard Delivery: 2-3 business days (£14.99)</p>
        <p>UK Express Delivery: Next business day (£24.99)</p>
        <p>International Shipping: 5-10 business days (£14.99)</p>
        
        <h3>Free Shipping</h3>
        <p>Free UK shipping on orders over £100</p>
        
        <h3>Processing Time</h3>
        <p>Orders are processed within 1-2 business days</p>
      `
    },
    {
      title: 'Returns & Exchanges',
      content: `
        <h3>Return Period</h3>
        <p>30-day return period from delivery date</p>
        
        <h3>Condition Requirements</h3>
        <p>Items must be in original condition with all packaging</p>
        <p>Custom or personalized items cannot be returned</p>
        
        <h3>Return Process</h3>
        <p>Contact us at info@craftedkettles.com to initiate a return</p>
        <p>Return shipping costs are covered by the customer unless item is defective</p>
      `
    },
    {
      title: 'Warranty',
      content: `
        <h3>Coverage Period</h3>
        <p>2-year manufacturer warranty from purchase date</p>
        
        <h3>What's Covered</h3>
        <p>Manufacturing defects and movement malfunctions</p>
        <p>Water resistance failure under normal use</p>
        
        <h3>What's Not Covered</h3>
        <p>Damage from misuse, accidents, or normal wear</p>
        <p>Damage from unauthorized repairs or modifications</p>
        <p>Scratches on case, bracelet, or crystal</p>
      `
    },
    {
      title: 'Privacy Policy',
      content: `
        <h3>Information We Collect</h3>
        <p>Personal information provided during purchase or account creation</p>
        <p>Order history and preferences</p>
        <p>Website usage data through cookies</p>
        
        <h3>How We Use Information</h3>
        <p>Process orders and provide customer service</p>
        <p>Send order updates and shipping notifications</p>
        <p>Improve our website and services</p>
        
        <h3>Data Protection</h3>
        <p>We use SSL encryption to protect your data</p>
        <p>We never sell or share personal information with third parties</p>
        <p>You can request data deletion by contacting us</p>
      `
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#4B302D] mb-4">
            Policies
          </h1>
          <p className="text-xl text-[#4B302D]/70">
            Important information about shipping, returns, warranty, and privacy
          </p>
        </div>

        <div className="space-y-12">
          {policies.map((policy, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-8">
              <h2 className="text-2xl font-bold text-[#4B302D] mb-6">
                {policy.title}
              </h2>
              <div 
                className="prose prose-gray max-w-none"
                dangerouslySetInnerHTML={{ __html: policy.content }}
              />
            </div>
          ))}
        </div>

        <div className="mt-16 bg-[#BD6A5C] rounded-lg p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">
            Questions About Our Policies?
          </h2>
          <p className="mb-6">
            If you have any questions about our policies or need assistance with your order, 
            our customer service team is here to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="mailto:info@craftedkettles.com" className="text-white hover:text-gray-200">
              Email: info@craftedkettles.com
            </a>
            <a href="tel:+447392614868" className="text-white hover:text-gray-200">
              Phone: +44 7392 614868
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
