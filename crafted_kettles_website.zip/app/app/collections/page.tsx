
import Link from 'next/link'
import Image from 'next/image'
import { ArrowRight, Watch } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { formatPrice } from '@/lib/currency'
import { prisma } from '@/lib/db'

export const metadata = {
  title: 'Watch Collections | Crafted Kettles',
  description: 'Explore our luxury watch collections: SeikoJust, Seiko Santos, SeikoNaut, and Royal SeikOak. Each collection offers unique style and precision engineering.',
}

async function getCollections() {
  try {
    const collections = await prisma.collection.findMany({
      orderBy: {
        price: 'asc'
      },
      include: {
        _count: {
          select: {
            products: true
          }
        }
      }
    })

    // Convert Decimal to number for client component compatibility
    const serializedCollections = collections.map((collection: any) => ({
      ...collection,
      price: Number(collection.price)
    }))

    return serializedCollections
  } catch (error) {
    console.error('Error fetching collections:', error)
    return []
  }
}

export default async function CollectionsPage() {
  const collections = await getCollections()

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5E6CA] via-white to-[#D6B79E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-[#4B302D] mb-4">
            Our Collections
          </h1>
          <p className="text-xl text-[#4B302D]/70 max-w-3xl mx-auto">
            Each collection represents a unique fusion of Japanese precision and luxury aesthetics, 
            crafted for the modern connoisseur who appreciates exceptional value.
          </p>
        </div>

        {/* Collections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {collections?.map((collection: any, index: number) => (
            <Card key={collection.id} className="bg-white/70 backdrop-blur-sm shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
              <CardContent className="p-0">
                {/* Collection Image */}
                <div className="relative h-80 overflow-hidden">
                  {collection.image && (
                    <Image
                      src={collection.image}
                      alt={collection.name}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                      sizes="(max-width: 768px) 100vw, 50vw"
                    />
                  )}
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300" />
                  
                  {/* Collection Badge */}
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                    <span className="text-[#4B302D] font-semibold text-sm">
                      {collection._count.products}+ Models
                    </span>
                  </div>
                </div>

                {/* Collection Details */}
                <div className="p-8 space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold text-[#4B302D] group-hover:text-[#BD6A5C] transition-colors">
                      {collection.name}
                    </h2>
                    <div className="flex items-center gap-2 text-[#BD6A5C]">
                      <Watch className="w-5 h-5" />
                      <span className="font-semibold">
                        From {formatPrice(Number(collection.price), 'GBP')}
                      </span>
                    </div>
                  </div>

                  <p className="text-[#4B302D]/70 leading-relaxed">
                    {collection.description}
                  </p>

                  <div className="pt-4">
                    <Link href={`/collections/${collection.slug}`}>
                      <Button className="w-full bg-[#BD6A5C] hover:bg-[#4B302D] text-white group-hover:scale-105 transition-all duration-300">
                        Explore {collection.name}
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Why Choose Our Collections */}
        <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-8 lg:p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-[#4B302D] mb-4">
              Why Choose Crafted Kettles
            </h2>
            <p className="text-[#4B302D]/70 max-w-2xl mx-auto">
              Our commitment to excellence ensures every timepiece meets the highest standards of luxury and precision
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-[#BD6A5C] rounded-full flex items-center justify-center mx-auto">
                <Watch className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#4B302D]">Premium Movements</h3>
              <p className="text-[#4B302D]/70">
                Every watch features carefully selected and modified Seiko movements for exceptional reliability and precision
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-[#BD6A5C] rounded-full flex items-center justify-center mx-auto">
                <span className="text-white font-bold text-lg">2Y</span>
              </div>
              <h3 className="text-xl font-semibold text-[#4B302D]">2-Year Warranty</h3>
              <p className="text-[#4B302D]/70">
                Comprehensive warranty coverage ensures your investment is protected with full service support
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-[#BD6A5C] rounded-full flex items-center justify-center mx-auto">
                <span className="text-white font-bold text-sm">£££</span>
              </div>
              <h3 className="text-xl font-semibold text-[#4B302D]">Accessible Luxury</h3>
              <p className="text-[#4B302D]/70">
                High-end luxury timepieces at prices that make premium watchmaking accessible to all enthusiasts
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
