

import { Suspense } from 'react'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowLeft, Star, Sparkles } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ProductCard } from '@/components/product/product-card'
import { prisma } from '@/lib/db'

export const dynamic = "force-dynamic";

async function getCollection(slug: string) {
  try {
    const collection = await prisma.collection.findUnique({
      where: { slug },
      include: {
        products: {
          where: { inStock: true },
          orderBy: { createdAt: 'desc' }
        }
      }
    })

    if (!collection) return null

    // Convert Decimal to number for client component compatibility
    const serializedCollection = {
      ...collection,
      price: Number(collection.price),
      products: collection.products.map((product: any) => ({
        ...product,
        price: Number(product.price),
        originalPrice: product.originalPrice ? Number(product.originalPrice) : null,
      }))
    }

    return serializedCollection
  } catch (error) {
    console.error('Error fetching collection:', error)
    return null
  }
}

interface CollectionPageProps {
  params: {
    slug: string
  }
}

export async function generateMetadata({ params }: CollectionPageProps) {
  const collection = await getCollection(params.slug)
  
  if (!collection) {
    return {
      title: 'Collection Not Found | Crafted Kettles',
      description: 'The requested watch collection could not be found.',
    }
  }

  return {
    title: `${collection.name} Collection | Crafted Kettles`,
    description: collection.description || `Explore the ${collection.name} luxury watch collection from Crafted Kettles.`,
    openGraph: {
      title: `${collection.name} Collection | Crafted Kettles`,
      description: collection.description || `Explore the ${collection.name} luxury watch collection`,
      images: collection.image ? [collection.image] : [],
    },
  }
}

export default async function CollectionPage({ params }: CollectionPageProps) {
  const collection = await getCollection(params.slug)

  if (!collection) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5E6CA] via-[#D6B79E] to-[#BD6A5C]">
      {/* Hero Section */}
      <section className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Navigation */}
          <div className="mb-8">
            <Link 
              href="/collections"
              className="inline-flex items-center text-[#4B302D] hover:text-[#BD6A5C] transition-colors group"
            >
              <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
              Back to Collections
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Collection Image */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-white/20 backdrop-blur-sm">
              {collection.image ? (
                <Image
                  src={collection.image}
                  alt={collection.name}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <Sparkles className="w-16 h-16 text-[#4B302D]/50" />
                </div>
              )}
            </div>

            {/* Collection Info */}
            <div className="space-y-8">
              <div>
                <h1 className="text-5xl lg:text-6xl font-bold text-[#4B302D] mb-6">
                  {collection.name}
                </h1>
                <p className="text-xl text-[#4B302D]/80 leading-relaxed max-w-2xl">
                  {collection.description || `Discover the exquisite ${collection.name} collection, where precision meets luxury in every timepiece.`}
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                  </div>
                  <span className="text-sm text-[#4B302D]/70">
                    Rated 5.0/5 by our customers
                  </span>
                </div>

                <div className="text-3xl font-bold text-[#4B302D]">
                  Starting from £{collection.price}
                </div>

                <div className="text-sm text-[#4B302D]/60">
                  Free international shipping • 2-year warranty
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/shop" className="flex-1">
                  <Button size="lg" className="w-full bg-[#BD6A5C] hover:bg-[#4B302D] text-white">
                    Shop Collection
                  </Button>
                </Link>
                <Link href="/contact" className="flex-1">
                  <Button size="lg" variant="outline" className="w-full border-[#4B302D] text-[#4B302D] hover:bg-[#4B302D] hover:text-white">
                    Custom Order
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      {collection.products.length > 0 && (
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-[#4B302D] mb-4">
                Available Timepieces
              </h2>
              <p className="text-xl text-[#4B302D]/70">
                Each piece is crafted with precision and attention to detail
              </p>
            </div>

            <Suspense fallback={
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-96 bg-gray-100 rounded-lg animate-pulse" />
                ))}
              </div>
            }>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {collection.products.map((product: any) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </Suspense>

            {collection.products.length === 0 && (
              <div className="text-center py-12">
                <Sparkles className="w-16 h-16 text-[#4B302D]/30 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-[#4B302D] mb-2">
                  Coming Soon
                </h3>
                <p className="text-[#4B302D]/70 mb-6">
                  New timepieces in this collection are being crafted
                </p>
                <Link href="/collections">
                  <Button variant="outline" className="border-[#4B302D] text-[#4B302D] hover:bg-[#4B302D] hover:text-white">
                    Explore Other Collections
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Call to Action */}
      <section className="py-16 bg-[#4B302D] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Ready to Own a {collection.name} Timepiece?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Each watch is individually crafted and can be customized to your preferences. 
            Contact us on Instagram for personalized modifications.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://instagram.com/craftedkettles" target="_blank">
              <Button size="lg" className="bg-white text-[#4B302D] hover:bg-gray-100">
                Contact on Instagram
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-[#4B302D]">
                Email Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
