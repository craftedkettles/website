
import Link from 'next/link'
import Image from 'next/image'
import { Calendar, User, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { prisma } from '@/lib/db'

export const metadata = {
  title: 'Watch Blog | Crafted Kettles',
  description: 'Discover insights about luxury watches, modified Seiko timepieces, and the art of horology from our expert team.',
}

async function getBlogPosts() {
  try {
    const posts = await prisma.blogPost.findMany({
      where: {
        published: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return posts
  } catch (error) {
    console.error('Error fetching blog posts:', error)
    return []
  }
}

export default async function BlogPage() {
  const posts = await getBlogPosts()

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold text-[#4B302D] mb-4">
            Watch Insights & Stories
          </h1>
          <p className="text-xl text-[#4B302D]/70 max-w-3xl mx-auto">
            Discover the world of luxury timepieces, from craftsmanship techniques to 
            collecting advice and industry insights from our expert team.
          </p>
        </div>

        {/* Blog Posts */}
        {posts?.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post: any) => (
              <Card key={post.id} className="bg-white shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden group">
                {/* Featured Image */}
                {post.featuredImage && (
                  <div className="relative h-48 overflow-hidden">
                    <Image
                      src={post.featuredImage}
                      alt={post.title}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                  </div>
                )}

                <CardHeader className="space-y-4">
                  {/* Meta Information */}
                  <div className="flex items-center gap-4 text-sm text-[#4B302D]/60">
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      <span>{post.author}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  {/* Tags */}
                  {post.tags?.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {post.tags.map((tag: string) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Title */}
                  <h2 className="text-xl font-bold text-[#4B302D] group-hover:text-[#BD6A5C] transition-colors">
                    <Link href={`/blog/${post.slug}`}>
                      {post.title}
                    </Link>
                  </h2>
                </CardHeader>

                <CardContent>
                  {/* Excerpt */}
                  {post.excerpt && (
                    <p className="text-[#4B302D]/70 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>
                  )}

                  {/* Read More */}
                  <Link href={`/blog/${post.slug}`}>
                    <Button variant="outline" className="group border-[#BD6A5C] text-[#BD6A5C] hover:bg-[#BD6A5C] hover:text-white">
                      Read More
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <h3 className="text-2xl font-semibold text-[#4B302D] mb-4">
              Coming Soon
            </h3>
            <p className="text-[#4B302D]/70 max-w-md mx-auto">
              We're working on exciting content about luxury watches, craftsmanship, and collecting. 
              Check back soon for expert insights and stories.
            </p>
          </div>
        )}

        {/* Newsletter Signup */}
        <div className="mt-20 bg-gradient-to-r from-[#4B302D] to-[#BD6A5C] rounded-2xl p-8 lg:p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">
            Stay Updated
          </h2>
          <p className="text-white/90 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter for the latest blog posts, new collection announcements, 
            and exclusive insights from the world of luxury timepieces.
          </p>
          <Link href="/#newsletter">
            <Button size="lg" className="bg-white text-[#BD6A5C] hover:bg-white/90">
              Subscribe to Newsletter
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
