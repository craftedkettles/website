
import { Suspense } from 'react'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { ArrowLeft, Calendar, Clock, User } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { prisma } from '@/lib/db'

interface PageProps {
  params: {
    slug: string
  }
}

async function getBlogPost(slug: string) {
  try {
    const post = await prisma.blogPost.findUnique({
      where: {
        slug: slug,
        published: true
      }
    })

    return post
  } catch (error) {
    console.error('Error fetching blog post:', error)
    return null
  }
}

async function getRelatedPosts(currentSlug: string) {
  try {
    const posts = await prisma.blogPost.findMany({
      where: {
        published: true,
        slug: {
          not: currentSlug
        }
      },
      take: 3,
      orderBy: {
        createdAt: 'desc'
      }
    })

    return posts
  } catch (error) {
    console.error('Error fetching related posts:', error)
    return []
  }
}

export async function generateStaticParams() {
  try {
    const posts = await prisma.blogPost.findMany({
      where: { published: true },
      select: { slug: true }
    })

    return posts.map((post) => ({
      slug: post.slug
    }))
  } catch (error) {
    console.error('Error generating static params:', error)
    return []
  }
}

export async function generateMetadata({ params }: PageProps) {
  const post = await getBlogPost(params.slug)
  
  if (!post) {
    return {
      title: 'Post Not Found',
      description: 'The requested blog post could not be found.'
    }
  }

  return {
    title: `${post.title} | Crafted Kettles Blog`,
    description: post.excerpt || post.content.substring(0, 160),
    openGraph: {
      title: post.title,
      description: post.excerpt || post.content.substring(0, 160),
      images: post.featuredImage ? [post.featuredImage] : [],
      type: 'article',
      publishedTime: post.createdAt.toISOString(),
      authors: [post.author]
    }
  }
}

export default async function BlogPostPage({ params }: PageProps) {
  const [post, relatedPosts] = await Promise.all([
    getBlogPost(params.slug),
    getRelatedPosts(params.slug)
  ])

  if (!post) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E]">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <Link href="/blog" className="inline-flex items-center text-[#BD6A5C] hover:text-[#4B302D] transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </Link>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Article Header */}
        <Card className="overflow-hidden shadow-lg mb-8">
          {post.featuredImage && (
            <div className="relative aspect-[2/1] bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E]">
              <Image
                src={post.featuredImage}
                alt={post.title}
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 1200px"
              />
              <div className="absolute inset-0 bg-black/20" />
            </div>
          )}
          
          <CardContent className="p-8">
            <div className="space-y-4">
              {/* Tags */}
              {post.tags && post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="bg-[#BD6A5C]/10 text-[#BD6A5C] hover:bg-[#BD6A5C]/20">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Title */}
              <h1 className="text-3xl md:text-4xl font-bold text-[#4B302D] leading-tight">
                {post.title}
              </h1>

              {/* Excerpt */}
              {post.excerpt && (
                <p className="text-xl text-gray-600 leading-relaxed">
                  {post.excerpt}
                </p>
              )}

              {/* Meta Info */}
              <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500 pt-4 border-t border-gray-200">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>{new Date(post.createdAt).toLocaleDateString('en-GB', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{Math.ceil(post.content.length / 1000)} min read</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Article Content */}
        <Card className="shadow-lg mb-8">
          <CardContent className="p-8">
            <div className="prose prose-lg max-w-none prose-headings:text-[#4B302D] prose-p:text-gray-700 prose-p:leading-relaxed prose-a:text-[#BD6A5C] prose-a:no-underline hover:prose-a:text-[#4B302D] prose-strong:text-[#4B302D] prose-blockquote:border-[#BD6A5C] prose-blockquote:text-gray-600">
              {/* Convert content to paragraphs */}
              {post.content.split('\n\n').map((paragraph, index) => (
                <p key={index} className="mb-6 last:mb-0">
                  {paragraph}
                </p>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-[#4B302D]">Related Articles</h2>
            
            <div className="grid md:grid-cols-3 gap-6">
              {relatedPosts.map((relatedPost) => (
                <Link key={relatedPost.id} href={`/blog/${relatedPost.slug}`}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                    {relatedPost.featuredImage && (
                      <div className="relative aspect-video bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E]">
                        <Image
                          src={relatedPost.featuredImage}
                          alt={relatedPost.title}
                          fill
                          className="object-cover rounded-t-lg"
                          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 33vw, 400px"
                        />
                      </div>
                    )}
                    
                    <CardContent className="p-6">
                      <div className="space-y-2">
                        <h3 className="font-semibold text-[#4B302D] line-clamp-2 hover:text-[#BD6A5C] transition-colors">
                          {relatedPost.title}
                        </h3>
                        
                        {relatedPost.excerpt && (
                          <p className="text-sm text-gray-600 line-clamp-3">
                            {relatedPost.excerpt}
                          </p>
                        )}
                        
                        <div className="text-xs text-gray-500">
                          {new Date(relatedPost.createdAt).toLocaleDateString('en-GB')}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
            
            <div className="text-center">
              <Button asChild className="bg-[#BD6A5C] hover:bg-[#4B302D]">
                <Link href="/blog">
                  View All Articles
                </Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
