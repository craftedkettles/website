
import { Suspense } from 'react'
import { HeroSection } from '@/components/sections/hero-section'
import { FeaturedProducts } from '@/components/sections/featured-products'
import { AboutBrand } from '@/components/sections/about-brand'
import { CollectionsPreview } from '@/components/sections/collections-preview'
import { InstagramFeed } from '@/components/sections/instagram-feed'
import { NewsletterSignup } from '@/components/sections/newsletter-signup'

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <Suspense fallback={<div className="h-96 bg-gray-100 animate-pulse" />}>
        <FeaturedProducts />
      </Suspense>
      <AboutBrand />
      <Suspense fallback={<div className="h-96 bg-gray-50 animate-pulse" />}>
        <CollectionsPreview />
      </Suspense>
      <InstagramFeed />
      <NewsletterSignup />
    </>
  )
}
