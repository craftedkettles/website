
'use client'

import { SessionProvider } from 'next-auth/react'
import { ThemeProvider } from '@/components/theme-provider'
import { CartProvider } from '@/hooks/use-cart'
import { CurrencyProvider } from '@/hooks/use-currency'
import { useEffect, useState } from 'react'

export function Providers({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <SessionProvider>
      <ThemeProvider
        attribute="class"
        defaultTheme="light"
        enableSystem={false}
        disableTransitionOnChange
      >
        <CurrencyProvider>
          <CartProvider>
            {mounted ? children : <div style={{ opacity: 0 }}>{children}</div>}
          </CartProvider>
        </CurrencyProvider>
      </ThemeProvider>
    </SessionProvider>
  )
}
