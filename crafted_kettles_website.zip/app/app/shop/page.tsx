
import { Suspense } from 'react'
import { ProductCard } from '@/components/product/product-card'
import { ProductFilters } from '@/components/product/product-filters'
import { prisma } from '@/lib/db'

export const dynamic = "force-dynamic";

export const metadata = {
  title: 'Shop Luxury Watches | Crafted Kettles',
  description: 'Browse our collection of luxury modified Seiko watches. Premium timepieces with exceptional craftsmanship and accessible pricing.',
}

async function getProducts(searchParams: any = {}) {
  try {
    const { collection, sortBy, priceRange } = searchParams
    
    const where: any = {
      inStock: true
    }

    if (collection && collection !== 'all') {
      where.collection = {
        slug: collection
      }
    }

    let orderBy: any = { createdAt: 'desc' }
    
    if (sortBy === 'price-asc') {
      orderBy = { price: 'asc' }
    } else if (sortBy === 'price-desc') {
      orderBy = { price: 'desc' }
    } else if (sortBy === 'name') {
      orderBy = { name: 'asc' }
    }

    const products = await prisma.product.findMany({
      where,
      include: {
        collection: true
      },
      orderBy
    })

    // Convert Decimal to number for client component compatibility
    const serializedProducts = products.map((product: any) => ({
      ...product,
      price: Number(product.price),
      originalPrice: product.originalPrice ? Number(product.originalPrice) : null,
      collection: product.collection ? {
        ...product.collection,
        price: Number(product.collection.price)
      } : null
    }))

    return serializedProducts
  } catch (error) {
    console.error('Error fetching products:', error)
    return []
  }
}

async function getCollections() {
  try {
    const collections = await prisma.collection.findMany({
      orderBy: {
        name: 'asc'
      }
    })
    
    // Convert Decimal to number for client component compatibility
    const serializedCollections = collections.map((collection: any) => ({
      ...collection,
      price: Number(collection.price)
    }))
    
    return serializedCollections
  } catch (error) {
    console.error('Error fetching collections:', error)
    return []
  }
}

export default async function ShopPage({ 
  searchParams 
}: { 
  searchParams: { [key: string]: string | string[] | undefined } 
}) {
  const products = await getProducts(searchParams)
  const collections = await getCollections()

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-[#4B302D] mb-4">
            Luxury Watch Collection
          </h1>
          <p className="text-xl text-[#4B302D]/70">
            Discover precision-engineered timepieces where craftsmanship meets luxury
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <Suspense fallback={<div className="h-64 bg-white rounded-lg animate-pulse" />}>
              <ProductFilters collections={collections} />
            </Suspense>
          </div>

          {/* Products Grid */}
          <div className="lg:w-3/4">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-[#4B302D]/70">
                {products?.length} {products?.length === 1 ? 'watch' : 'watches'} found
              </p>
            </div>

            <Suspense fallback={
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-96 bg-white rounded-lg animate-pulse" />
                ))}
              </div>
            }>
              {products?.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {products.map((product: any) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <h3 className="text-xl font-semibold text-[#4B302D] mb-2">
                    No watches found
                  </h3>
                  <p className="text-[#4B302D]/70">
                    Try adjusting your filters or browse all collections
                  </p>
                </div>
              )}
            </Suspense>
          </div>
        </div>
      </div>
    </div>
  )
}
