
'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { loadStripe } from '@stripe/stripe-js'
import { Elements } from '@stripe/react-stripe-js'
import { motion } from 'framer-motion'
import { CheckoutForm } from '@/components/checkout/checkout-form'
import { OrderSummary } from '@/components/checkout/order-summary'
import { useCart } from '@/hooks/use-cart'
import { useCurrency } from '@/hooks/use-currency'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, Lock } from 'lucide-react'
import Link from 'next/link'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

export default function CheckoutPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { items, totalAmount, itemCount, clearCart, isLoading: cartLoading } = useCart()
  const { currency } = useCurrency()
  const [clientSecret, setClientSecret] = useState<string>('')
  const [orderId, setOrderId] = useState<string>('')
  const [orderNumber, setOrderNumber] = useState<string>('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string>('')
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !cartLoading && items?.length === 0) {
      router.push('/cart')
      return
    }
  }, [items, router, mounted, cartLoading])

  const handleCreatePaymentIntent = async (orderData: any) => {
    setIsLoading(true)
    setError('')

    try {
      const response = await fetch('/api/checkout/create-payment-intent', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          items: items.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
          })),
          currency,
          ...orderData,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create payment intent')
      }

      setClientSecret(data.clientSecret)
      setOrderId(data.orderId)
      setOrderNumber(data.orderNumber)

    } catch (error) {
      console.error('Payment intent creation error:', error)
      setError(error instanceof Error ? error.message : 'Failed to process checkout')
    } finally {
      setIsLoading(false)
    }
  }

  const handlePaymentSuccess = async (paymentIntentId: string) => {
    try {
      const response = await fetch('/api/checkout/confirm-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ paymentIntentId }),
      })

      const data = await response.json()

      if (response.ok) {
        await clearCart()
        router.push(`/thank-you?order=${data.order.id}&orderNumber=${data.order.orderNumber}`)
      } else {
        throw new Error(data.error || 'Payment confirmation failed')
      }
    } catch (error) {
      console.error('Payment confirmation error:', error)
      setError(error instanceof Error ? error.message : 'Payment confirmation failed')
    }
  }

  // Show loading state while cart is loading or before mount
  if (!mounted || cartLoading || items?.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-[#BD6A5C]"></div>
          <p className="mt-4 text-[#4B302D]">Loading checkout...</p>
        </div>
      </div>
    )
  }

  const appearance = {
    theme: 'stripe' as const,
    variables: {
      colorPrimary: '#BD6A5C',
      colorBackground: '#ffffff',
      colorText: '#4B302D',
      colorDanger: '#df1b41',
      fontFamily: 'system-ui, sans-serif',
      spacingUnit: '4px',
      borderRadius: '8px',
    },
  }

  const options = {
    clientSecret,
    appearance,
    loader: 'auto' as const,
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link 
            href="/cart" 
            className="inline-flex items-center text-[#BD6A5C] hover:text-[#4B302D] transition-colors mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cart
          </Link>
          
          <div className="flex items-center gap-3 mb-2">
            <Lock className="w-6 h-6 text-[#BD6A5C]" />
            <h1 className="text-3xl font-bold text-[#4B302D]">
              Secure Checkout
            </h1>
          </div>
          <p className="text-[#4B302D]/70">
            Complete your order for {itemCount} luxury timepiece{itemCount !== 1 ? 's' : ''}
          </p>
        </div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6"
          >
            {error}
          </motion.div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Checkout Form */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D]">Contact Information</CardTitle>
              </CardHeader>
              <CardContent>
                {!clientSecret ? (
                  <CheckoutForm
                    session={session}
                    onSubmit={handleCreatePaymentIntent}
                    isLoading={isLoading}
                  />
                ) : (
                  <Elements options={options} stripe={stripePromise}>
                    <CheckoutForm
                      session={session}
                      clientSecret={clientSecret}
                      orderId={orderId}
                      orderNumber={orderNumber}
                      onPaymentSuccess={handlePaymentSuccess}
                      onSubmit={handleCreatePaymentIntent}
                      isLoading={isLoading}
                    />
                  </Elements>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:sticky lg:top-8">
            <OrderSummary 
              items={items}
              currency={currency}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
