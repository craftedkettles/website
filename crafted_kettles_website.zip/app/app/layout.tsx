
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Toaster } from 'sonner'
import { Providers } from './providers'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Crafted Kettles - Luxury Modified Seiko Watches',
  description: 'Discover luxury modified Seiko watches at accessible prices. Precision engineering meets distinctive design in our SeikoJust, Santos, SeikoNaut & Royal SeikOak collections.',
  keywords: 'luxury watches, modified Seiko watches, affordable luxury timepieces, Arabic dial, watch collections',
  authors: [{ name: 'Crafted Kettles' }],
  creator: 'Crafted Kettles',
  publisher: 'Crafted Kettles',
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: 'https://craftedkettles.com',
    title: 'Crafted Kettles - Luxury Modified Seiko Watches',
    description: 'Discover luxury modified Seiko watches at accessible prices. Precision engineering meets distinctive design.',
    siteName: 'Crafted Kettles',
    images: [{
      url: 'https://cdn.abacus.ai/images/a043a86a-1ac3-4280-8ac8-a4b533d04c69.png',
      width: 1024,
      height: 1024,
    }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Crafted Kettles - Luxury Modified Seiko Watches',
    description: 'Discover luxury modified Seiko watches at accessible prices.',
    images: ['https://cdn.abacus.ai/images/a043a86a-1ac3-4280-8ac8-a4b533d04c69.png']
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          <Header />
          <main className="min-h-screen pt-16">
            {children}
          </main>
          <Footer />
          <Toaster position="bottom-right" />
        </Providers>
      </body>
    </html>
  )
}
