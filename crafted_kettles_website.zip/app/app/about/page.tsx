
'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import Image from 'next/image'
import { Heart, Award, Users, Globe, Instagram, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export default function AboutPage() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  const values = [
    {
      icon: Heart,
      title: 'Passion for Craftsmanship',
      description: 'Every timepiece is a labor of love, meticulously crafted with attention to detail that honors the art of horology.'
    },
    {
      icon: Award,
      title: 'Quality Excellence',
      description: 'We source only the finest components and employ rigorous quality control to ensure each watch meets luxury standards.'
    },
    {
      icon: Users,
      title: 'Community-Driven',
      description: 'Our Instagram and TikTok community shapes our designs, ensuring we create watches that resonate with modern enthusiasts.'
    },
    {
      icon: Globe,
      title: 'Global Accessibility',
      description: 'Bringing luxury watch ownership to enthusiasts worldwide with international shipping and accessible pricing.'
    }
  ]

  const stats = [
    { number: '1000+', label: 'Happy Customers' },
    { number: '30+', label: 'Unique Models' },
    { number: '4', label: 'Collections' },
    { number: '2Y', label: 'Warranty' }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F5E6CA] via-white to-[#D6B79E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl lg:text-5xl font-bold text-[#4B302D] mb-6"
          >
            The Story Behind
            <span className="text-[#BD6A5C] block">Crafted Kettles</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl text-[#4B302D]/70 max-w-3xl mx-auto"
          >
            Where passion meets precision. We transform exceptional Seiko movements into luxury timepieces that rival the finest Swiss watches, making true luxury accessible to every watch enthusiast.
          </motion.p>
        </div>

        {/* Brand Story */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <h2 className="text-3xl font-bold text-[#4B302D]">
              Our Philosophy
            </h2>
            <div className="space-y-4 text-[#4B302D]/80 leading-relaxed">
              <p>
                Founded on the belief that exceptional timepieces shouldn't require exceptional budgets, Crafted Kettles emerged from a passion for democratizing luxury watchmaking.
              </p>
              <p>
                We discovered that Japanese Seiko movements—renowned for their reliability and precision—could be transformed into stunning luxury pieces that compete with watches costing ten times more.
              </p>
              <p>
                Our microbrand philosophy focuses on quality over quantity, creating limited collections that showcase unique aesthetics while maintaining the mechanical excellence Seiko is famous for.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-[4/3] bg-white/20 backdrop-blur-sm rounded-2xl p-8 shadow-2xl">
              <div className="relative w-full h-full rounded-xl overflow-hidden">
                <Image
                  src="https://cdn.abacus.ai/images/38608a2d-e5da-41d4-a5c0-929484ff2778.png"
                  alt="Crafted Kettles workshop craftsmanship"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Values Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#4B302D] mb-4">
              Our Values
            </h2>
            <p className="text-[#4B302D]/70 max-w-2xl mx-auto">
              The principles that guide every decision, every design, and every interaction with our community
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="bg-white/50 backdrop-blur-sm shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-[#BD6A5C] rounded-lg flex items-center justify-center flex-shrink-0">
                        <value.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-[#4B302D] mb-3">
                          {value.title}
                        </h3>
                        <p className="text-[#4B302D]/70 leading-relaxed">
                          {value.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-8 lg:p-12 mb-20">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl lg:text-4xl font-bold text-[#BD6A5C] mb-2">
                  {stat.number}
                </div>
                <div className="text-[#4B302D]/70 font-medium">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Community Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-[#4B302D] mb-6">
            Join Our Community
          </h2>
          <p className="text-[#4B302D]/70 max-w-2xl mx-auto mb-8">
            Follow our journey and connect with fellow watch enthusiasts on social media. 
            Share your Crafted Kettles timepiece and inspire others in the community.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://instagram.com/craftedkettles"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
                <Instagram className="w-5 h-5 mr-2" />
                Follow on Instagram
              </Button>
            </a>
            
            <a
              href="https://tiktok.com/@craftedkettles"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C] hover:bg-[#BD6A5C] hover:text-white">
                <TrendingUp className="w-5 h-5 mr-2" />
                Follow on TikTok
              </Button>
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
