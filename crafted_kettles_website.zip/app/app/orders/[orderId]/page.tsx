
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatPrice } from '@/lib/currency'
import { ArrowLeft, Package, Truck, MapPin, CreditCard, Calendar, Loader2 } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

interface Order {
  id: string
  orderNumber: string
  status: string
  paymentStatus: string
  total: string
  subtotal: string
  shippingCost: string
  tax: string
  currency: string
  customerEmail: string
  customerName: string
  customerPhone?: string | null
  paymentMethod?: string | null
  createdAt: string
  orderItems: Array<{
    id: string
    quantity: number
    price: string
    product: {
      id: string
      name: string
      slug: string
      featuredImage?: string | null
      shortDescription?: string | null
    }
  }>
  shippingAddress?: {
    firstName: string
    lastName: string
    company?: string | null
    addressLine1: string
    addressLine2?: string | null
    city: string
    state?: string | null
    postalCode: string
    country: string
    phone?: string | null
  }
  billingAddress?: {
    firstName: string
    lastName: string
    company?: string | null
    addressLine1: string
    addressLine2?: string | null
    city: string
    state?: string | null
    postalCode: string
    country: string
    phone?: string | null
  }
}

export default function OrderDetailsPage({ 
  params 
}: { 
  params: { orderId: string } 
}) {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchOrder()
  }, [params.orderId])

  const fetchOrder = async () => {
    try {
      const response = await fetch(`/api/orders/${params.orderId}`)
      
      if (!response.ok) {
        if (response.status === 404) {
          setError('Order not found')
        } else if (response.status === 401) {
          setError('Unauthorized to view this order')
        } else {
          setError('Failed to load order')
        }
        return
      }
      
      const data = await response.json()
      setOrder(data)
    } catch (error) {
      console.error('Error fetching order:', error)
      setError('Failed to load order details')
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'processing': return 'bg-purple-100 text-purple-800 border-purple-200'
      case 'shipped': return 'bg-green-100 text-green-800 border-green-200'
      case 'delivered': return 'bg-emerald-100 text-emerald-800 border-emerald-200'
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200'
      case 'refunded': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const getPaymentStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'paid': return 'bg-green-100 text-green-800 border-green-200'
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'failed': return 'bg-red-100 text-red-800 border-red-200'
      case 'refunded': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#BD6A5C] mx-auto mb-4" />
          <p className="text-[#4B302D]/70">Loading order details...</p>
        </div>
      </div>
    )
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-[#4B302D] mb-2">Order Not Found</h1>
          <p className="text-[#4B302D]/70 mb-6">{error}</p>
          <div className="flex gap-4 justify-center">
            <Link href="/account">
              <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C]">
                View All Orders
              </Button>
            </Link>
            <Link href="/">
              <Button className="bg-[#BD6A5C] hover:bg-[#4B302D]">
                Return Home
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link 
          href="/account"
          className="inline-flex items-center text-[#BD6A5C] hover:text-[#4B302D] transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Account
        </Link>

        {/* Order Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-[#4B302D] mb-2">
                Order {order.orderNumber}
              </h1>
              <div className="flex items-center gap-2 text-sm text-[#4B302D]/70">
                <Calendar className="w-4 h-4" />
                <span>Placed on {new Date(order.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
            <div className="flex items-center gap-3 mt-4 sm:mt-0">
              <Badge className={getStatusColor(order.status)}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </Badge>
              <Badge className={getPaymentStatusColor(order.paymentStatus)}>
                Payment {order.paymentStatus.charAt(0).toUpperCase() + order.paymentStatus.slice(1)}
              </Badge>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Items */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D] flex items-center gap-2">
                  <Package className="w-5 h-5 text-[#BD6A5C]" />
                  Items ({order.orderItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.orderItems.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex gap-4 p-4 border border-gray-200 rounded-lg"
                    >
                      <div className="relative w-20 h-20 bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E] rounded-lg overflow-hidden flex-shrink-0">
                        {item.product?.featuredImage && (
                          <Image
                            src={item.product.featuredImage}
                            alt={item.product?.name || 'Product'}
                            fill
                            className="object-cover"
                            sizes="80px"
                          />
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-semibold text-[#4B302D] mb-1">
                          <Link 
                            href={`/products/${item.product?.slug}`}
                            className="hover:text-[#BD6A5C] transition-colors"
                          >
                            {item.product?.name}
                          </Link>
                        </h4>
                        {item.product?.shortDescription && (
                          <p className="text-sm text-[#4B302D]/70 mb-2">
                            {item.product.shortDescription}
                          </p>
                        )}
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-[#4B302D]/70">
                            Quantity: {item.quantity}
                          </span>
                          <div className="text-right">
                            <div className="text-sm text-[#4B302D]/70">
                              {formatPrice(Number(item.price), order.currency)} each
                            </div>
                            <div className="font-semibold text-[#4B302D]">
                              {formatPrice(Number(item.price) * item.quantity, order.currency)}
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Shipping Address */}
            {order.shippingAddress && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-[#4B302D] flex items-center gap-2">
                    <Truck className="w-5 h-5 text-[#BD6A5C]" />
                    Shipping Address
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-[#4B302D]">
                    <p className="font-medium">
                      {order.shippingAddress.firstName} {order.shippingAddress.lastName}
                    </p>
                    {order.shippingAddress.company && (
                      <p>{order.shippingAddress.company}</p>
                    )}
                    <p>{order.shippingAddress.addressLine1}</p>
                    {order.shippingAddress.addressLine2 && (
                      <p>{order.shippingAddress.addressLine2}</p>
                    )}
                    <p>
                      {order.shippingAddress.city}
                      {order.shippingAddress.state && `, ${order.shippingAddress.state}`}{' '}
                      {order.shippingAddress.postalCode}
                    </p>
                    <p>{order.shippingAddress.country}</p>
                    {order.shippingAddress.phone && (
                      <p className="mt-2 text-sm text-[#4B302D]/70">
                        Phone: {order.shippingAddress.phone}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Order Summary & Details */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D]">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-[#4B302D]/70">Subtotal</span>
                  <span className="text-[#4B302D]">
                    {formatPrice(Number(order.subtotal), order.currency)}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-[#4B302D]/70">Shipping</span>
                  <span className="text-[#4B302D]">
                    {Number(order.shippingCost) === 0 ? (
                      <span className="text-green-600 font-medium">Free</span>
                    ) : (
                      formatPrice(Number(order.shippingCost), order.currency)
                    )}
                  </span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-[#4B302D]/70">Tax</span>
                  <span className="text-[#4B302D]">
                    {formatPrice(Number(order.tax), order.currency)}
                  </span>
                </div>
                
                <Separator />
                
                <div className="flex justify-between text-lg font-bold">
                  <span className="text-[#4B302D]">Total</span>
                  <span className="text-[#4B302D]">
                    {formatPrice(Number(order.total), order.currency)}
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Customer & Payment Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D] flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-[#BD6A5C]" />
                  Customer & Payment
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-[#4B302D]/70">Customer</p>
                  <p className="font-medium text-[#4B302D]">{order.customerName}</p>
                </div>
                
                <div>
                  <p className="text-sm text-[#4B302D]/70">Email</p>
                  <p className="text-[#4B302D]">{order.customerEmail}</p>
                </div>
                
                {order.customerPhone && (
                  <div>
                    <p className="text-sm text-[#4B302D]/70">Phone</p>
                    <p className="text-[#4B302D]">{order.customerPhone}</p>
                  </div>
                )}
                
                {order.paymentMethod && (
                  <div>
                    <p className="text-sm text-[#4B302D]/70">Payment Method</p>
                    <p className="text-[#4B302D] capitalize">{order.paymentMethod}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Order Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D]">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {order.status === 'delivered' && (
                  <Button className="w-full bg-[#BD6A5C] hover:bg-[#4B302D]">
                    Reorder Items
                  </Button>
                )}
                
                <Button variant="outline" className="w-full border-[#BD6A5C] text-[#BD6A5C]">
                  Download Invoice
                </Button>
                
                <Link href="/contact">
                  <Button variant="outline" className="w-full">
                    Contact Support
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
