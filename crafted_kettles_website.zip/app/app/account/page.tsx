
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { formatPrice } from '@/lib/currency'
import { useCurrency } from '@/hooks/use-currency'
import { User, Package, MapPin, Settings, Eye, Loader2 } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

interface Order {
  id: string
  orderNumber: string
  status: string
  total: string
  currency: string
  createdAt: string
  orderItems: Array<{
    id: string
    quantity: number
    price: string
    product: {
      id: string
      name: string
      slug: string
      featuredImage?: string | null
    }
  }>
}

export default function AccountPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { currency } = useCurrency()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (status === 'loading') return
    
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }

    fetchOrders()
  }, [status, router])

  const fetchOrders = async () => {
    try {
      const response = await fetch('/api/orders')
      if (!response.ok) {
        throw new Error('Failed to fetch orders')
      }
      const data = await response.json()
      setOrders(data)
    } catch (error) {
      console.error('Error fetching orders:', error)
      setError('Failed to load orders')
    } finally {
      setIsLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'confirmed': return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'processing': return 'bg-purple-100 text-purple-800 border-purple-200'
      case 'shipped': return 'bg-green-100 text-green-800 border-green-200'
      case 'delivered': return 'bg-emerald-100 text-emerald-800 border-emerald-200'
      case 'cancelled': return 'bg-red-100 text-red-800 border-red-200'
      case 'refunded': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#BD6A5C]" />
      </div>
    )
  }

  if (!session) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-[#4B302D] mb-2">My Account</h1>
          <p className="text-[#4B302D]/70">
            Welcome back, {session.user?.name || session.user?.email}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Account Overview */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D] flex items-center gap-2">
                  <User className="w-5 h-5 text-[#BD6A5C]" />
                  Account Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-[#4B302D]/70">Name</p>
                  <p className="font-medium text-[#4B302D]">
                    {session.user?.name || 'Not provided'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-[#4B302D]/70">Email</p>
                  <p className="font-medium text-[#4B302D]">
                    {session.user?.email}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-[#4B302D]/70">Total Orders</p>
                  <p className="font-medium text-[#4B302D]">
                    {orders.length}
                  </p>
                </div>
                <Separator />
                <Button variant="outline" className="w-full border-[#BD6A5C] text-[#BD6A5C]">
                  <Settings className="w-4 h-4 mr-2" />
                  Account Settings
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Tabs defaultValue="orders" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="orders">Order History</TabsTrigger>
                <TabsTrigger value="addresses">Addresses</TabsTrigger>
                <TabsTrigger value="preferences">Preferences</TabsTrigger>
              </TabsList>

              {/* Orders Tab */}
              <TabsContent value="orders" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-[#4B302D] flex items-center gap-2">
                      <Package className="w-5 h-5 text-[#BD6A5C]" />
                      Order History
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="text-center py-8">
                        <Loader2 className="w-6 h-6 animate-spin text-[#BD6A5C] mx-auto mb-2" />
                        <p className="text-[#4B302D]/70">Loading orders...</p>
                      </div>
                    ) : error ? (
                      <div className="text-center py-8 text-red-600">
                        {error}
                      </div>
                    ) : orders.length === 0 ? (
                      <div className="text-center py-8">
                        <Package className="w-12 h-12 text-[#4B302D]/30 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-[#4B302D] mb-2">
                          No orders yet
                        </h3>
                        <p className="text-[#4B302D]/70 mb-4">
                          You haven't placed any orders yet. Start shopping to see your order history here.
                        </p>
                        <Link href="/shop">
                          <Button className="bg-[#BD6A5C] hover:bg-[#4B302D]">
                            Browse Products
                          </Button>
                        </Link>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {orders.map((order) => (
                          <motion.div
                            key={order.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-shadow"
                          >
                            {/* Order Header */}
                            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                              <div>
                                <h4 className="font-semibold text-[#4B302D]">
                                  Order {order.orderNumber}
                                </h4>
                                <p className="text-sm text-[#4B302D]/70">
                                  Placed on {new Date(order.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="flex items-center gap-3 mt-2 sm:mt-0">
                                <Badge className={getStatusColor(order.status)}>
                                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                </Badge>
                                <span className="font-semibold text-[#4B302D]">
                                  {formatPrice(Number(order.total), order.currency)}
                                </span>
                              </div>
                            </div>

                            {/* Order Items */}
                            <div className="space-y-2 mb-4">
                              {order.orderItems.slice(0, 2).map((item) => (
                                <div key={item.id} className="flex items-center gap-3">
                                  <div className="relative w-12 h-12 bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E] rounded overflow-hidden flex-shrink-0">
                                    {item.product?.featuredImage && (
                                      <Image
                                        src={item.product.featuredImage}
                                        alt={item.product?.name || 'Product'}
                                        fill
                                        className="object-cover"
                                        sizes="48px"
                                      />
                                    )}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-[#4B302D] truncate">
                                      {item.product?.name}
                                    </p>
                                    <p className="text-xs text-[#4B302D]/70">
                                      Qty: {item.quantity} × {formatPrice(Number(item.price), order.currency)}
                                    </p>
                                  </div>
                                </div>
                              ))}
                              {order.orderItems.length > 2 && (
                                <p className="text-sm text-[#4B302D]/70 ml-15">
                                  +{order.orderItems.length - 2} more item{order.orderItems.length - 2 !== 1 ? 's' : ''}
                                </p>
                              )}
                            </div>

                            {/* Order Actions */}
                            <div className="flex flex-wrap gap-2">
                              <Link href={`/orders/${order.id}`}>
                                <Button variant="outline" size="sm" className="border-[#BD6A5C] text-[#BD6A5C]">
                                  <Eye className="w-3 h-3 mr-2" />
                                  View Details
                                </Button>
                              </Link>
                              {order.status === 'delivered' && (
                                <Button variant="outline" size="sm">
                                  Reorder
                                </Button>
                              )}
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Addresses Tab */}
              <TabsContent value="addresses">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-[#4B302D] flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-[#BD6A5C]" />
                      Saved Addresses
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <MapPin className="w-12 h-12 text-[#4B302D]/30 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-[#4B302D] mb-2">
                        No saved addresses
                      </h3>
                      <p className="text-[#4B302D]/70 mb-4">
                        Save your addresses for faster checkout in the future.
                      </p>
                      <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C]">
                        Add Address
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Preferences Tab */}
              <TabsContent value="preferences">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-[#4B302D] flex items-center gap-2">
                      <Settings className="w-5 h-5 text-[#BD6A5C]" />
                      Account Preferences
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <Settings className="w-12 h-12 text-[#4B302D]/30 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-[#4B302D] mb-2">
                        Preferences
                      </h3>
                      <p className="text-[#4B302D]/70 mb-4">
                        Customize your account settings and preferences.
                      </p>
                      <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C]">
                        Update Preferences
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
