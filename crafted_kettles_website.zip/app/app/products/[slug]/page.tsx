
import { notFound } from 'next/navigation'
import { Metadata } from 'next'
import { ProductDetail } from '@/components/product/product-detail'
import { RelatedProducts } from '@/components/product/related-products'
import { prisma } from '@/lib/db'

interface ProductPageProps {
  params: {
    slug: string
  }
}

async function getProduct(slug: string) {
  try {
    const product = await prisma.product.findUnique({
      where: { slug },
      include: {
        collection: true
      }
    })

    if (!product) return null

    // Convert Decimal to number for client component compatibility
    const serializedProduct = {
      ...product,
      price: Number(product.price),
      originalPrice: product.originalPrice ? Number(product.originalPrice) : null,
      collection: product.collection ? {
        name: product.collection.name,
        slug: product.collection.slug
      } : undefined
    }

    return serializedProduct
  } catch (error) {
    console.error('Error fetching product:', error)
    return null
  }
}

async function getRelatedProducts(collectionId: string, currentProductId: string) {
  try {
    const products = await prisma.product.findMany({
      where: {
        collectionId,
        id: { not: currentProductId },
        inStock: true
      },
      include: {
        collection: true
      },
      take: 4
    })

    // Convert Decimal to number for client component compatibility
    const serializedProducts = products.map((product: any) => ({
      ...product,
      price: Number(product.price),
      originalPrice: product.originalPrice ? Number(product.originalPrice) : null,
      collection: product.collection ? {
        name: product.collection.name,
        slug: product.collection.slug
      } : undefined
    }))

    return serializedProducts
  } catch (error) {
    console.error('Error fetching related products:', error)
    return []
  }
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const product = await getProduct(params.slug)

  if (!product) {
    return {
      title: 'Product Not Found | Crafted Kettles'
    }
  }

  return {
    title: `${product.name} | Crafted Kettles`,
    description: product.shortDescription || product.description,
    openGraph: {
      title: `${product.name} | Crafted Kettles`,
      description: product.shortDescription || product.description || '',
      images: product.featuredImage ? [product.featuredImage] : [],
    },
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const product = await getProduct(params.slug)

  if (!product) {
    notFound()
  }

  const relatedProducts = await getRelatedProducts(product.collectionId, product.id)

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ProductDetail product={product} />
        
        {relatedProducts?.length > 0 && (
          <div className="mt-16">
            <RelatedProducts products={relatedProducts} />
          </div>
        )}
      </div>
    </div>
  )
}
