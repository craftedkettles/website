
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const collection = searchParams.get('collection')
    const featured = searchParams.get('featured')
    const inStock = searchParams.get('inStock')
    const limit = searchParams.get('limit')

    const where: any = {}
    
    if (collection) {
      where.collection = {
        slug: collection
      }
    }

    if (featured === 'true') {
      where.isFeatured = true
    }

    if (inStock === 'true') {
      where.inStock = true
    }

    const products = await prisma.product.findMany({
      where,
      include: {
        collection: true
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: limit ? parseInt(limit) : undefined
    })

    // Convert Decimal to number for JSON serialization
    const serializedProducts = products.map((product: any) => ({
      ...product,
      price: Number(product.price),
      originalPrice: product.originalPrice ? Number(product.originalPrice) : null,
      collection: product.collection ? {
        ...product.collection,
        price: Number(product.collection.price)
      } : null
    }))

    return NextResponse.json(serializedProducts)

  } catch (error) {
    console.error('Error fetching products:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
