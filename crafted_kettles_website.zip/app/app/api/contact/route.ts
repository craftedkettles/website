
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/db'

const contactSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Invalid email address'),
  subject: z.string().optional(),
  message: z.string().min(10, 'Message must be at least 10 characters long')
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { name, email, subject, message } = contactSchema.parse(body)

    // Save contact form submission to database
    await prisma.contactForm.create({
      data: {
        name,
        email,
        subject: subject || 'General Inquiry',
        message,
        status: 'unread'
      }
    })

    return NextResponse.json(
      { message: 'Contact form submitted successfully' },
      { status: 201 }
    )

  } catch (error) {
    console.error('Contact form submission error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid form data', details: error.errors },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Failed to submit contact form' },
      { status: 500 }
    )
  }
}
