
import { NextRequest, NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { stripe, STRIPE_WEBHOOKS_SECRET } from '@/lib/stripe'
import { prisma } from '@/lib/db'
import { sendOrderConfirmationEmail } from '@/lib/email'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = headers().get('stripe-signature')

    if (!signature) {
      console.error('Missing Stripe signature')
      return NextResponse.json(
        { error: 'Missing signature' },
        { status: 400 }
      )
    }

    let event
    try {
      event = stripe.webhooks.constructEvent(
        body,
        signature,
        STRIPE_WEBHOOKS_SECRET
      )
    } catch (error) {
      console.error('Webhook signature verification failed:', error)
      return NextResponse.json(
        { error: 'Invalid signature' },
        { status: 400 }
      )
    }

    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentSuccess(event.data.object)
        break
      
      case 'payment_intent.payment_failed':
        await handlePaymentFailure(event.data.object)
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })

  } catch (error) {
    console.error('Webhook error:', error)
    return NextResponse.json(
      { error: 'Webhook handler failed' },
      { status: 500 }
    )
  }
}

async function handlePaymentSuccess(paymentIntent: any) {
  try {
    console.log(`Payment succeeded: ${paymentIntent.id}`)

    // Find the order by payment intent ID
    const order = await prisma.order.findFirst({
      where: { paymentIntentId: paymentIntent.id },
      include: {
        orderItems: {
          include: {
            product: true
          }
        },
        shippingAddress: true,
        billingAddress: true,
      }
    })

    if (!order) {
      console.error(`Order not found for payment intent: ${paymentIntent.id}`)
      return
    }

    // Update order status
    const updatedOrder = await prisma.order.update({
      where: { id: order.id },
      data: {
        status: 'CONFIRMED',
        paymentStatus: 'PAID',
        paymentMethod: paymentIntent.payment_method_types?.[0] || 'card',
      },
      include: {
        orderItems: {
          include: {
            product: true
          }
        },
        shippingAddress: true,
      }
    })

    // Update product stock quantities
    for (const orderItem of order.orderItems) {
      await prisma.product.update({
        where: { id: orderItem.productId },
        data: {
          stockQuantity: {
            decrement: orderItem.quantity
          }
        }
      })
    }

    // Send order confirmation email
    try {
      await sendOrderConfirmationEmail(updatedOrder)
    } catch (emailError) {
      console.error('Failed to send confirmation email:', emailError)
      // Don't fail the entire webhook if email fails
    }

    console.log(`Order ${order.orderNumber} successfully processed`)

  } catch (error) {
    console.error('Error handling payment success:', error)
    throw error
  }
}

async function handlePaymentFailure(paymentIntent: any) {
  try {
    console.log(`Payment failed: ${paymentIntent.id}`)

    // Find and update the order
    await prisma.order.updateMany({
      where: { paymentIntentId: paymentIntent.id },
      data: {
        paymentStatus: 'FAILED',
        status: 'CANCELLED',
      }
    })

    console.log(`Order updated for failed payment: ${paymentIntent.id}`)

  } catch (error) {
    console.error('Error handling payment failure:', error)
    throw error
  }
}
