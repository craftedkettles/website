
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/db'

const subscribeSchema = z.object({
  email: z.string().email('Invalid email address')
})

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { email } = subscribeSchema.parse(body)

    // Check if email is already subscribed
    const existingSubscription = await prisma.newsletter.findUnique({
      where: { email }
    })

    if (existingSubscription) {
      if (existingSubscription.status === 'active') {
        return NextResponse.json(
          { message: 'You are already subscribed to our newsletter' },
          { status: 200 }
        )
      } else {
        // Reactivate subscription
        await prisma.newsletter.update({
          where: { email },
          data: { status: 'active', updatedAt: new Date() }
        })
        return NextResponse.json(
          { message: 'Subscription reactivated successfully' },
          { status: 200 }
        )
      }
    }

    // Create new subscription
    await prisma.newsletter.create({
      data: {
        email,
        status: 'active'
      }
    })

    return NextResponse.json(
      { message: 'Successfully subscribed to newsletter' },
      { status: 201 }
    )

  } catch (error) {
    console.error('Newsletter subscription error:', error)
    
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid email address' },
        { status: 400 }
      )
    }

    return NextResponse.json(
      { error: 'Failed to subscribe. Please try again.' },
      { status: 500 }
    )
  }
}
