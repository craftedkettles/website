
import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { stripe, SHIPPING_COSTS, INTERNATIONAL_SHIPPING_GBP, UK_POSTCODES_REGEX } from '@/lib/stripe'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const body = await request.json()
    
    const { 
      items, 
      currency = 'GBP', 
      shippingAddress,
      billingAddress,
      customerEmail,
      customerName,
      customerPhone 
    } = body

    if (!items || items.length === 0) {
      return NextResponse.json({ error: 'No items in cart' }, { status: 400 })
    }

    if (!customerEmail || !customerName) {
      return NextResponse.json({ error: 'Customer details required' }, { status: 400 })
    }

    // Calculate order totals
    let subtotal = 0
    const orderItems = []

    // Validate products and calculate totals
    for (const item of items) {
      const product = await prisma.product.findUnique({
        where: { id: item.productId },
      })

      if (!product) {
        return NextResponse.json({ error: `Product not found: ${item.productId}` }, { status: 400 })
      }

      if (!product.inStock || product.stockQuantity < item.quantity) {
        return NextResponse.json({ 
          error: `Insufficient stock for ${product.name}` 
        }, { status: 400 })
      }

      const itemTotal = Number(product.price) * item.quantity
      subtotal += itemTotal

      orderItems.push({
        productId: product.id,
        quantity: item.quantity,
        price: product.price,
      })
    }

    // Calculate shipping based on address
    const isUKAddress = shippingAddress?.country === 'GB' || 
                      UK_POSTCODES_REGEX.test(shippingAddress?.postalCode || '')
    
    // Shipping costs: £4.99 for UK, £14.99 for international
    let shippingCost = 0
    if (isUKAddress) {
      shippingCost = SHIPPING_COSTS.GBP // £4.99 for UK
    } else {
      // For international orders
      if (currency === 'GBP') {
        shippingCost = INTERNATIONAL_SHIPPING_GBP // £14.99
      } else if (currency === 'USD') {
        shippingCost = 18.99 // ~£14.99 in USD
      } else if (currency === 'EUR') {
        shippingCost = 16.99 // ~£14.99 in EUR
      } else {
        shippingCost = INTERNATIONAL_SHIPPING_GBP // Fallback to £14.99
      }
    }
    
    // No VAT calculation since all prices already include VAT
    const tax = 0
    const total = subtotal + shippingCost

    // Generate unique order number
    const orderNumber = `CK-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`

    // Create order in database
    const order = await prisma.order.create({
      data: {
        orderNumber,
        userId: session?.user?.id || null,
        customerEmail,
        customerName,
        customerPhone: customerPhone || null,
        subtotal,
        shippingCost,
        tax,
        total,
        currency,
        status: 'PENDING',
        paymentStatus: 'PENDING',
        orderItems: {
          create: orderItems
        },
        ...(shippingAddress && {
          shippingAddress: {
            create: {
              firstName: shippingAddress.firstName,
              lastName: shippingAddress.lastName,
              company: shippingAddress.company || null,
              addressLine1: shippingAddress.addressLine1,
              addressLine2: shippingAddress.addressLine2 || null,
              city: shippingAddress.city,
              state: shippingAddress.state || null,
              postalCode: shippingAddress.postalCode,
              country: shippingAddress.country,
              phone: shippingAddress.phone || null,
              userId: session?.user?.id || null,
            }
          }
        }),
        ...(billingAddress && {
          billingAddress: {
            create: {
              firstName: billingAddress.firstName,
              lastName: billingAddress.lastName,
              company: billingAddress.company || null,
              addressLine1: billingAddress.addressLine1,
              addressLine2: billingAddress.addressLine2 || null,
              city: billingAddress.city,
              state: billingAddress.state || null,
              postalCode: billingAddress.postalCode,
              country: billingAddress.country,
              phone: billingAddress.phone || null,
              userId: session?.user?.id || null,
            }
          }
        }),
      },
      include: {
        orderItems: {
          include: {
            product: true
          }
        }
      }
    })

    // Create Stripe PaymentIntent
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(total * 100), // Convert to cents
      currency: currency.toLowerCase(),
      automatic_payment_methods: {
        enabled: true,
      },
      metadata: {
        orderId: order.id,
        orderNumber: order.orderNumber,
        customerEmail,
      },
      description: `Crafted Kettles Order ${order.orderNumber}`,
      shipping: shippingAddress ? {
        name: `${shippingAddress.firstName} ${shippingAddress.lastName}`,
        address: {
          line1: shippingAddress.addressLine1,
          line2: shippingAddress.addressLine2 || undefined,
          city: shippingAddress.city,
          state: shippingAddress.state || undefined,
          postal_code: shippingAddress.postalCode,
          country: shippingAddress.country,
        },
      } : undefined,
    })

    // Update order with payment intent ID
    await prisma.order.update({
      where: { id: order.id },
      data: { paymentIntentId: paymentIntent.id }
    })

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      orderId: order.id,
      orderNumber: order.orderNumber,
    })

  } catch (error) {
    console.error('Payment intent creation error:', error)
    return NextResponse.json(
      { error: 'Failed to create payment intent' },
      { status: 500 }
    )
  }
}
