
import { NextRequest, NextResponse } from 'next/server'
import { stripe } from '@/lib/stripe'
import { prisma } from '@/lib/db'
import { sendOrderConfirmationEmail } from '@/lib/email'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const { paymentIntentId } = await request.json()

    if (!paymentIntentId) {
      return NextResponse.json({ error: 'Payment intent ID required' }, { status: 400 })
    }

    // Retrieve the payment intent from Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)

    if (paymentIntent.status !== 'succeeded') {
      return NextResponse.json({ error: 'Payment not completed' }, { status: 400 })
    }

    // Find the order by payment intent ID
    const order = await prisma.order.findFirst({
      where: { paymentIntentId },
      include: {
        orderItems: {
          include: {
            product: true
          }
        },
        shippingAddress: true,
        billingAddress: true,
      }
    })

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    }

    // Update order status
    const updatedOrder = await prisma.order.update({
      where: { id: order.id },
      data: {
        status: 'CONFIRMED',
        paymentStatus: 'PAID',
        paymentMethod: paymentIntent.payment_method_types?.[0] || 'card',
      },
      include: {
        orderItems: {
          include: {
            product: true
          }
        },
        shippingAddress: true,
      }
    })

    // Update product stock quantities
    for (const orderItem of order.orderItems) {
      await prisma.product.update({
        where: { id: orderItem.productId },
        data: {
          stockQuantity: {
            decrement: orderItem.quantity
          }
        }
      })
    }

    // Send order confirmation email
    try {
      await sendOrderConfirmationEmail(updatedOrder)
    } catch (emailError) {
      console.error('Failed to send confirmation email:', emailError)
      // Don't fail the entire request if email fails
    }

    return NextResponse.json({
      success: true,
      order: {
        id: updatedOrder.id,
        orderNumber: updatedOrder.orderNumber,
        status: updatedOrder.status,
        total: updatedOrder.total.toString(),
        currency: updatedOrder.currency,
      }
    })

  } catch (error) {
    console.error('Payment confirmation error:', error)
    return NextResponse.json(
      { error: 'Failed to confirm payment' },
      { status: 500 }
    )
  }
}
