
'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { RainbowButton } from '@/components/ui/rainbow-button'
import { formatPrice } from '@/lib/currency'
import { CheckCircle, Package, Mail, ArrowRight, Download, Loader2 } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'

interface Order {
  id: string
  orderNumber: string
  status: string
  total: string
  currency: string
  customerEmail: string
  customerName: string
  createdAt: string
  orderItems: Array<{
    id: string
    quantity: number
    price: string
    product: {
      id: string
      name: string
      slug: string
      featuredImage?: string | null
    }
  }>
  shippingAddress?: {
    firstName: string
    lastName: string
    addressLine1: string
    addressLine2?: string | null
    city: string
    state?: string | null
    postalCode: string
    country: string
  }
}

function ThankYouContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  const orderId = searchParams.get('order')
  const orderNumber = searchParams.get('orderNumber')

  useEffect(() => {
    if (!orderId && !orderNumber) {
      router.push('/')
      return
    }

    fetchOrder()
  }, [orderId, orderNumber, router])

  const fetchOrder = async () => {
    if (!orderId) return

    try {
      const url = orderNumber 
        ? `/api/orders/${orderId}?orderNumber=${orderNumber}`
        : `/api/orders/${orderId}`
        
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error('Failed to fetch order')
      }
      
      const data = await response.json()
      setOrder(data)
    } catch (error) {
      console.error('Error fetching order:', error)
      setError('Failed to load order details')
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#BD6A5C] mx-auto mb-4" />
          <p className="text-[#4B302D]/70">Loading your order details...</p>
        </div>
      </div>
    )
  }

  if (error || !order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Package className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-[#4B302D] mb-2">Order Not Found</h1>
          <p className="text-[#4B302D]/70 mb-6">{error || 'Unable to find your order details.'}</p>
          <Link href="/">
            <RainbowButton>Return to Home</RainbowButton>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Success Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-600" />
          </div>
          
          <h1 className="text-3xl font-bold text-[#4B302D] mb-2">
            Order Confirmed!
          </h1>
          <p className="text-lg text-[#4B302D]/70">
            Thank you for your order, {order.customerName}. We're preparing your luxury timepiece.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D] flex items-center gap-2">
                  <Package className="w-5 h-5 text-[#BD6A5C]" />
                  Order Details
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-[#4B302D]/70">Order Number</span>
                  <span className="font-mono font-semibold text-[#4B302D]">
                    {order.orderNumber}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-[#4B302D]/70">Order Date</span>
                  <span className="text-[#4B302D]">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-[#4B302D]/70">Status</span>
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-[#4B302D]/70">Email</span>
                  <span className="text-[#4B302D]">
                    {order.customerEmail}
                  </span>
                </div>

                <Separator />

                <div className="flex justify-between items-center text-lg font-bold">
                  <span className="text-[#4B302D]">Total</span>
                  <span className="text-[#4B302D]">
                    {formatPrice(Number(order.total), order.currency)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Order Items */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D]">
                  Items Ordered ({order.orderItems.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {order.orderItems.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="relative w-16 h-16 bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E] rounded-lg overflow-hidden flex-shrink-0">
                        {item.product?.featuredImage && (
                          <Image
                            src={item.product.featuredImage}
                            alt={item.product?.name || 'Product'}
                            fill
                            className="object-cover"
                            sizes="64px"
                          />
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-medium text-[#4B302D]">
                          <Link 
                            href={`/products/${item.product?.slug}`}
                            className="hover:text-[#BD6A5C] transition-colors"
                          >
                            {item.product?.name}
                          </Link>
                        </h4>
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm text-[#4B302D]/70">
                            Qty: {item.quantity}
                          </span>
                          <span className="font-semibold text-[#4B302D]">
                            {formatPrice(Number(item.price) * item.quantity, order.currency)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Shipping Address */}
        {order.shippingAddress && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-8"
          >
            <Card>
              <CardHeader>
                <CardTitle className="text-[#4B302D]">Shipping Address</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-[#4B302D]">
                  <p className="font-medium">
                    {order.shippingAddress.firstName} {order.shippingAddress.lastName}
                  </p>
                  <p>{order.shippingAddress.addressLine1}</p>
                  {order.shippingAddress.addressLine2 && (
                    <p>{order.shippingAddress.addressLine2}</p>
                  )}
                  <p>
                    {order.shippingAddress.city}
                    {order.shippingAddress.state && `, ${order.shippingAddress.state}`}{' '}
                    {order.shippingAddress.postalCode}
                  </p>
                  <p>{order.shippingAddress.country}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Next Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-[#4B302D]">What's Next?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#BD6A5C] mt-0.5" />
                <div>
                  <h4 className="font-medium text-[#4B302D]">Confirmation Email</h4>
                  <p className="text-sm text-[#4B302D]/70">
                    We've sent a confirmation email to {order.customerEmail} with your order details.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Package className="w-5 h-5 text-[#BD6A5C] mt-0.5" />
                <div>
                  <h4 className="font-medium text-[#4B302D]">Processing & Shipping</h4>
                  <p className="text-sm text-[#4B302D]/70">
                    Your order will be processed within 1-2 business days. You'll receive tracking information once shipped.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8 flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Link href="/account">
            <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C]">
              <Package className="w-4 h-4 mr-2" />
              View Order History
            </Button>
          </Link>
          
          <Link href="/shop">
            <RainbowButton>
              Continue Shopping
              <ArrowRight className="w-4 h-4 ml-2" />
            </RainbowButton>
          </Link>
        </motion.div>

        {/* Contact Support */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-8 text-center text-sm text-[#4B302D]/60"
        >
          <p>
            Questions about your order? 
            <Link href="/contact" className="text-[#BD6A5C] hover:underline ml-1">
              Contact our support team
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  )
}

export default function ThankYouPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#BD6A5C]" />
      </div>
    }>
      <ThankYouContent />
    </Suspense>
  )
}
