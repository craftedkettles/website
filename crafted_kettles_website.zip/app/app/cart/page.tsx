
'use client'

import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Minus, Plus, X, ShoppingBag, ArrowLeft, Truck, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { RainbowButton } from '@/components/ui/rainbow-button'
import { useCart } from '@/hooks/use-cart'
import { useCurrency } from '@/hooks/use-currency'
import { formatPrice } from '@/lib/currency'

export default function CartPage() {
  const { items, updateQuantity, removeItem, totalAmount, itemCount } = useCart()
  const { currency } = useCurrency()
  const [isUpdating, setIsUpdating] = useState<string | null>(null)

  const shippingCost = 14.99
  const taxRate = 0.20
  const subtotal = totalAmount
  const tax = subtotal * taxRate
  const shipping = itemCount > 0 ? shippingCost : 0
  const total = subtotal + tax + shipping

  const handleUpdateQuantity = async (productId: string, newQuantity: number) => {
    setIsUpdating(productId)
    try {
      await updateQuantity(productId, newQuantity)
    } finally {
      setIsUpdating(null)
    }
  }

  if (!items?.length) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              <div className="w-24 h-24 bg-[#BD6A5C]/10 rounded-full flex items-center justify-center mx-auto">
                <ShoppingBag className="w-12 h-12 text-[#BD6A5C]" />
              </div>
              
              <div>
                <h1 className="text-2xl font-bold text-[#4B302D] mb-2">
                  Your Cart is Empty
                </h1>
                <p className="text-[#4B302D]/70">
                  Looks like you haven't added any luxury timepieces to your cart yet.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/shop">
                  <RainbowButton>
                    Continue Shopping
                  </RainbowButton>
                </Link>
                <Link href="/collections">
                  <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C]">
                    Browse Collections
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link 
          href="/shop" 
          className="inline-flex items-center text-[#BD6A5C] hover:text-[#4B302D] transition-colors mb-8"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Continue Shopping
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <h1 className="text-2xl font-bold text-[#4B302D] mb-6">
                  Shopping Cart ({itemCount} {itemCount === 1 ? 'item' : 'items'})
                </h1>

                <div className="space-y-6">
                  {items.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      className="flex flex-col sm:flex-row gap-4 p-4 border border-gray-200 rounded-lg"
                    >
                      {/* Product Image */}
                      <div className="relative w-full sm:w-24 h-48 sm:h-24 bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E] rounded-lg overflow-hidden flex-shrink-0">
                        {item.product?.featuredImage && (
                          <Image
                            src={item.product.featuredImage}
                            alt={item.product?.name || 'Product'}
                            fill
                            className="object-cover"
                            sizes="96px"
                          />
                        )}
                      </div>

                      {/* Product Details */}
                      <div className="flex-1 space-y-2">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="font-semibold text-[#4B302D]">
                              <Link 
                                href={`/products/${item.product?.slug}`}
                                className="hover:text-[#BD6A5C] transition-colors"
                              >
                                {item.product?.name}
                              </Link>
                            </h3>
                            <p className="text-sm text-[#4B302D]/70">
                              {formatPrice(item.product?.price || 0, currency)}
                            </p>
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.productId)}
                            className="text-gray-400 hover:text-red-500 p-1"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* Quantity Controls */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center border border-gray-300 rounded-md">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.productId, item.quantity - 1)}
                              disabled={item.quantity <= 1 || isUpdating === item.productId}
                              className="px-2 py-1"
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                            
                            <span className="px-4 py-1 text-sm font-medium">
                              {item.quantity}
                            </span>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleUpdateQuantity(item.productId, item.quantity + 1)}
                              disabled={isUpdating === item.productId}
                              className="px-2 py-1"
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                          </div>

                          <div className="font-semibold text-[#4B302D]">
                            {formatPrice((item.product?.price || 0) * item.quantity, currency)}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardContent className="p-6">
                <h2 className="text-xl font-bold text-[#4B302D] mb-4">
                  Order Summary
                </h2>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatPrice(subtotal, currency)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{formatPrice(shipping, currency)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>VAT (20%)</span>
                    <span>{formatPrice(tax, currency)}</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span>{formatPrice(total, currency)}</span>
                  </div>
                </div>

                <div className="mt-6 space-y-4">
                  <Link href="/checkout">
                    <RainbowButton className="w-full">
                      Proceed to Checkout
                    </RainbowButton>
                  </Link>
                  
                  <div className="text-xs text-[#4B302D]/60 space-y-2">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-[#BD6A5C]" />
                      <span>Secure SSL encryption</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Truck className="w-4 h-4 text-[#BD6A5C]" />
                      <span>Free UK shipping over £100</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
