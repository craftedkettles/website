
import Stripe from 'stripe'

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing STRIPE_SECRET_KEY environment variable')
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  // Using the latest supported API version
  typescript: true,
})

export const STRIPE_WEBHOOKS_SECRET = process.env.STRIPE_WEBHOOK_SECRET || ''

// Currency configuration for multi-currency support
export const SUPPORTED_CURRENCIES = {
  GBP: { symbol: '£', name: 'British Pound' },
  USD: { symbol: '$', name: 'US Dollar' },
  EUR: { symbol: '€', name: 'Euro' },
} as const

export type SupportedCurrency = keyof typeof SUPPORTED_CURRENCIES

// Shipping costs by currency
export const SHIPPING_COSTS = {
  GBP: 4.99,  // Standard UK shipping
  USD: 18.99, // International shipping (converted from £14.99)  
  EUR: 16.99, // International shipping (converted from £14.99)
} as const

// International shipping cost in GBP
export const INTERNATIONAL_SHIPPING_GBP = 14.99

export const UK_POSTCODES_REGEX = /^([A-Z]{1,2}[0-9][A-Z0-9]? ?[0-9][A-Z]{2})$/i
