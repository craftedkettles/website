
import { Decimal } from '@prisma/client/runtime/library'

export interface Product {
  id: string
  name: string
  slug: string
  description?: string | null
  shortDescription?: string | null
  price: Decimal
  originalPrice?: Decimal | null
  sku: string
  inStock: boolean
  stockQuantity: number
  images: string[]
  featuredImage?: string | null
  dialColor?: string | null
  caseSize?: string | null
  caseMaterial?: string | null
  movement?: string | null
  waterResistance?: string | null
  braceletType?: string | null
  weight?: string | null
  features: string[]
  specifications?: any
  collectionId: string
  collection?: Collection
  isFeatured: boolean
  isNewArrival: boolean
  createdAt: Date
  updatedAt: Date
}

export interface Collection {
  id: string
  name: string
  slug: string
  description?: string | null
  image?: string | null
  price: Decimal
  createdAt: Date
  updatedAt: Date
  products?: Product[]
}

export interface CartItem {
  id: string
  productId: string
  quantity: number
  product: Product
  createdAt: Date
  updatedAt: Date
}

export interface User {
  id: string
  name?: string | null
  firstName?: string | null
  lastName?: string | null
  email: string
  phone?: string | null
  role: string
  createdAt: Date
  updatedAt: Date
}

export interface Order {
  id: string
  orderNumber: string
  customerEmail: string
  customerName: string
  customerPhone?: string | null
  status: 'PENDING' | 'CONFIRMED' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED' | 'REFUNDED'
  subtotal: Decimal
  shippingCost: Decimal
  tax: Decimal
  total: Decimal
  currency: string
  paymentMethod?: string | null
  paymentStatus: 'PENDING' | 'PAID' | 'FAILED' | 'REFUNDED'
  orderItems: OrderItem[]
  createdAt: Date
  updatedAt: Date
}

export interface OrderItem {
  id: string
  productId: string
  quantity: number
  price: Decimal
  product: Product
}

export interface Address {
  id: string
  firstName: string
  lastName: string
  company?: string | null
  addressLine1: string
  addressLine2?: string | null
  city: string
  state?: string | null
  postalCode: string
  country: string
  phone?: string | null
  isDefault: boolean
}

export interface ContactForm {
  id: string
  name: string
  email: string
  subject?: string | null
  message: string
  status: string
  createdAt: Date
}

export interface BlogPost {
  id: string
  title: string
  slug: string
  excerpt?: string | null
  content: string
  featuredImage?: string | null
  published: boolean
  author: string
  tags: string[]
  metaTitle?: string | null
  metaDescription?: string | null
  createdAt: Date
  updatedAt: Date
}

export interface ShippingOption {
  id: string
  name: string
  price: number
  estimatedDays: string
  description?: string
}

export interface Currency {
  code: string
  name: string
  symbol: string
  rate: number
}
