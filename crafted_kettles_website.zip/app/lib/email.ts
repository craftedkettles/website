
import nodemailer from 'nodemailer'
import { formatPrice } from './currency'

// Email configuration - in production, you'd use a service like SendGrid, Mailgun, etc.
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'localhost',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: process.env.SMTP_USER ? {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  } : undefined,
})

export async function sendOrderConfirmationEmail(order: any) {
  try {
    const orderItemsHtml = order.orderItems
      .map((item: any) => `
        <tr>
          <td style="padding: 10px; border-bottom: 1px solid #eee;">
            ${item.product.name}
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: center;">
            ${item.quantity}
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">
            ${formatPrice(Number(item.price), order.currency)}
          </td>
          <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">
            ${formatPrice(Number(item.price) * item.quantity, order.currency)}
          </td>
        </tr>
      `)
      .join('')

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Order Confirmation - ${order.orderNumber}</title>
      </head>
      <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="color: #BD6A5C; margin: 0;">Crafted Kettles</h1>
          <p style="color: #666; margin: 5px 0;">Luxury Reimagined</p>
        </div>

        <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <h2 style="color: #4B302D; margin: 0 0 10px 0;">Order Confirmation</h2>
          <p style="margin: 0; color: #666;">Thank you for your order! We're preparing your luxury timepiece for shipment.</p>
        </div>

        <div style="margin-bottom: 20px;">
          <h3 style="color: #4B302D;">Order Details</h3>
          <p><strong>Order Number:</strong> ${order.orderNumber}</p>
          <p><strong>Order Date:</strong> ${new Date(order.createdAt).toLocaleDateString()}</p>
          <p><strong>Email:</strong> ${order.customerEmail}</p>
        </div>

        <div style="margin-bottom: 20px;">
          <h3 style="color: #4B302D;">Items Ordered</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <thead>
              <tr style="background: #f5f5f5;">
                <th style="padding: 10px; text-align: left; border-bottom: 1px solid #ddd;">Product</th>
                <th style="padding: 10px; text-align: center; border-bottom: 1px solid #ddd;">Qty</th>
                <th style="padding: 10px; text-align: right; border-bottom: 1px solid #ddd;">Price</th>
                <th style="padding: 10px; text-align: right; border-bottom: 1px solid #ddd;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${orderItemsHtml}
            </tbody>
          </table>
        </div>

        <div style="background: #f9f9f9; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
          <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <span>Subtotal:</span>
            <span>${formatPrice(Number(order.subtotal), order.currency)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <span>Shipping:</span>
            <span>${formatPrice(Number(order.shippingCost), order.currency)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
            <span>Tax:</span>
            <span>${formatPrice(Number(order.tax), order.currency)}</span>
          </div>
          <div style="display: flex; justify-content: space-between; font-weight: bold; font-size: 18px; border-top: 1px solid #ddd; padding-top: 10px;">
            <span>Total:</span>
            <span>${formatPrice(Number(order.total), order.currency)}</span>
          </div>
        </div>

        ${order.shippingAddress ? `
          <div style="margin-bottom: 20px;">
            <h3 style="color: #4B302D;">Shipping Address</h3>
            <p style="margin: 5px 0;">${order.shippingAddress.firstName} ${order.shippingAddress.lastName}</p>
            ${order.shippingAddress.company ? `<p style="margin: 5px 0;">${order.shippingAddress.company}</p>` : ''}
            <p style="margin: 5px 0;">${order.shippingAddress.addressLine1}</p>
            ${order.shippingAddress.addressLine2 ? `<p style="margin: 5px 0;">${order.shippingAddress.addressLine2}</p>` : ''}
            <p style="margin: 5px 0;">${order.shippingAddress.city}, ${order.shippingAddress.state || ''} ${order.shippingAddress.postalCode}</p>
            <p style="margin: 5px 0;">${order.shippingAddress.country}</p>
          </div>
        ` : ''}

        <div style="border-top: 1px solid #eee; padding-top: 20px; text-align: center; color: #666;">
          <p>Questions about your order? Contact us at orders@craftedkettles.com</p>
          <p style="margin-top: 20px;">
            <a href="https://craftedkettles.com" style="color: #BD6A5C; text-decoration: none;">Visit Our Website</a> |
            <a href="https://craftedkettles.com/orders/${order.id}" style="color: #BD6A5C; text-decoration: none;">Track Your Order</a>
          </p>
        </div>

      </body>
      </html>
    `

    const mailOptions = {
      from: process.env.SMTP_FROM || 'orders@craftedkettles.com',
      to: order.customerEmail,
      subject: `Order Confirmation - ${order.orderNumber}`,
      html: emailHtml,
    }

    await transporter.sendMail(mailOptions)
    console.log(`Order confirmation email sent to ${order.customerEmail}`)

  } catch (error) {
    console.error('Email sending failed:', error)
    throw error
  }
}
