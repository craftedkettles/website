
export const SUPPORTED_CURRENCIES = {
  GBP: { symbol: '£', name: 'British Pound', rate: 1.0 },
  USD: { symbol: '$', name: 'US Dollar', rate: 1.25 },
  EUR: { symbol: '€', name: 'Euro', rate: 1.15 },
} as const

export type SupportedCurrency = keyof typeof SUPPORTED_CURRENCIES

export function formatPrice(
  price: number, 
  currency: string = 'GBP'
): string {
  const currencyInfo = SUPPORTED_CURRENCIES[currency as SupportedCurrency] || SUPPORTED_CURRENCIES.GBP
  
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(price)
}

export function convertPrice(
  basePrice: number, 
  fromCurrency: string = 'GBP', 
  toCurrency: string = 'GBP'
): number {
  if (fromCurrency === toCurrency) return basePrice
  
  const fromRate = SUPPORTED_CURRENCIES[fromCurrency as SupportedCurrency]?.rate || 1
  const toRate = SUPPORTED_CURRENCIES[toCurrency as SupportedCurrency]?.rate || 1
  
  // Convert to base currency (GBP) then to target currency
  const baseAmount = basePrice / fromRate
  return baseAmount * toRate
}

export function getCurrencySymbol(currency: string): string {
  return SUPPORTED_CURRENCIES[currency as SupportedCurrency]?.symbol || '£'
}
