import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-lg text-sm font-semibold ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:shadow-lg hover:shadow-primary/25 transform hover:scale-105 active:scale-95",
  {
    variants: {
      variant: {
        default: "bg-gradient-to-r from-[#BD6A5C] to-[#4B302D] text-white hover:from-[#4B302D] hover:to-[#BD6A5C] shadow-md hover:shadow-[#BD6A5C]/25",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-md hover:shadow-destructive/25",
        outline:
          "border-2 border-[#BD6A5C] bg-transparent text-[#BD6A5C] hover:bg-[#BD6A5C] hover:text-white backdrop-blur-sm hover:shadow-[#BD6A5C]/20",
        secondary:
          "bg-gradient-to-r from-[#F5E6CA] to-[#D6B79E] text-[#4B302D] hover:from-[#D6B79E] hover:to-[#BD6A5C] hover:text-white shadow-md",
        ghost: "hover:bg-[#F5E6CA]/50 text-[#4B302D] hover:text-[#BD6A5C] backdrop-blur-sm",
        link: "text-[#BD6A5C] underline-offset-4 hover:underline hover:text-[#4B302D]",
      },
      size: {
        default: "h-11 px-6 py-2.5",
        sm: "h-9 rounded-lg px-4 text-xs",
        lg: "h-13 rounded-xl px-10 py-3 text-base font-bold",
        icon: "h-11 w-11",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }