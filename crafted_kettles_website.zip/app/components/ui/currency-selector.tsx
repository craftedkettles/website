
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Check, ChevronDown, Globe } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { SUPPORTED_CURRENCIES } from '@/lib/currency'

interface CurrencySelectorProps {
  currentCurrency: string
  onCurrencyChange: (currency: string) => void
}

export function CurrencySelector({ 
  currentCurrency, 
  onCurrencyChange 
}: CurrencySelectorProps) {
  const [isOpen, setIsOpen] = useState(false)

  const currencies = Object.entries(SUPPORTED_CURRENCIES)

  const getCurrentCurrencyInfo = () => {
    return SUPPORTED_CURRENCIES[currentCurrency as keyof typeof SUPPORTED_CURRENCIES] || SUPPORTED_CURRENCIES.GBP
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm"
          className="flex items-center gap-1 text-[#4B302D] hover:text-[#BD6A5C] hover:bg-[#F5E6CA]/20"
        >
          <Globe className="w-4 h-4" />
          <span className="hidden sm:inline-block">
            {getCurrentCurrencyInfo().symbol}
          </span>
          <span className="text-xs">
            {currentCurrency}
          </span>
          <ChevronDown className="w-3 h-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-44">
        {currencies.map(([code, info]) => (
          <DropdownMenuItem
            key={code}
            onClick={() => {
              onCurrencyChange(code)
              setIsOpen(false)
            }}
            className="flex items-center justify-between cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <span className="font-medium">{info.symbol}</span>
              <span className="text-sm">{code}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 truncate">
                {info.name}
              </span>
              {currentCurrency === code && (
                <Check className="w-3 h-3 text-[#BD6A5C]" />
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
