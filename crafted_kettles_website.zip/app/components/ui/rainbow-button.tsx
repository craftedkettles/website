
'use client'

import { motion } from 'framer-motion'
import { forwardRef } from 'react'
import { cn } from '@/lib/utils'

interface RainbowButtonProps {
  children: React.ReactNode
  className?: string
  variant?: 'primary' | 'secondary'
  onClick?: () => void
  disabled?: boolean
  type?: 'button' | 'submit' | 'reset'
}

export const RainbowButton = forwardRef<HTMLButtonElement, RainbowButtonProps>(
  ({ children, className, variant = 'primary', onClick, disabled, type = 'button' }, ref) => {
    const brandColors = variant === 'primary' 
      ? ['#F5E6CA', '#D6B79E', '#BD6A5C', '#4B302D']
      : ['#BD6A5C', '#F5E6CA', '#D6B79E', '#4B302D']

    return (
      <motion.button
        ref={ref}
        type={type}
        disabled={disabled}
        onClick={onClick}
        className={cn(
          'relative overflow-hidden px-8 py-4 rounded-lg font-semibold text-white',
          'transition-all duration-300 transform hover:scale-105',
          'focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#BD6A5C]',
          disabled && 'opacity-50 cursor-not-allowed',
          className
        )}
        whileHover={disabled ? {} : { scale: 1.05 }}
        whileTap={disabled ? {} : { scale: 0.95 }}
      >
        <motion.div
          className="absolute inset-0 bg-gradient-to-r"
          style={{
            background: `linear-gradient(90deg, ${brandColors.join(', ')})`,
          }}
          animate={{
            backgroundPosition: ['0% 0%', '200% 0%'],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
        
        <motion.div
          className="absolute inset-0 opacity-0 hover:opacity-20"
          style={{
            background: `linear-gradient(-90deg, ${brandColors.join(', ')})`,
          }}
          whileHover={{ opacity: 0.2 }}
        />
        
        <span className="relative z-10 mix-blend-overlay text-[#4B302D] font-bold">
          {children}
        </span>
        
        <span className="absolute inset-0 z-20 flex items-center justify-center text-white font-bold">
          {children}
        </span>
      </motion.button>
    )
  }
)

RainbowButton.displayName = 'RainbowButton'
