
'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import Image from 'next/image'
import { Award, Heart, Users, Clock } from 'lucide-react'

export function AboutBrand() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  const features = [
    {
      icon: Award,
      title: 'Premium Quality',
      description: 'Every timepiece meets luxury standards with superior materials and finishing'
    },
    {
      icon: Heart,
      title: 'Passionate Craftsmanship', 
      description: 'Each watch is carefully modified and inspected by skilled artisans'
    },
    {
      icon: Users,
      title: 'Community Focused',
      description: 'Building connections with watch enthusiasts through Instagram and TikTok'
    },
    {
      icon: Clock,
      title: 'Timeless Design',
      description: 'Classic aesthetics enhanced with modern luxury touches that endure'
    }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-[#F5E6CA] to-[#D6B79E]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-[#4B302D] mb-6">
                The Art of
                <span className="text-[#BD6A5C] block">Luxury Modding</span>
              </h2>
              <p className="text-lg text-[#4B302D]/80 leading-relaxed">
                Crafted Kettles transforms exceptional Seiko movements into luxury timepieces 
                that rival the finest Swiss watches. Our microbrand philosophy combines Japanese 
                precision with bespoke aesthetics, making luxury accessible without compromise.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white/30 backdrop-blur-sm rounded-lg p-6 hover:bg-white/40 transition-all duration-300"
                >
                  <div className="flex items-start space-x-4">
                    <div className="bg-[#BD6A5C] p-2 rounded-lg">
                      <feature.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#4B302D] mb-2">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-[#4B302D]/70">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Images */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative space-y-6"
          >
            {/* Main Featured Image */}
            <div className="relative aspect-square bg-white/20 backdrop-blur-sm rounded-2xl p-8 shadow-2xl">
              <div className="relative w-full h-full rounded-xl overflow-hidden">
                <Image
                  src="/images/products/pink-seiko-mod.png"
                  alt="Pink Seiko Mod - Premium Crafted Kettles timepiece"
                  fill
                  className="object-cover hover:scale-105 transition-transform duration-500"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-[#BD6A5C] text-white px-4 py-2 rounded-full text-sm font-semibold shadow-lg">
                Premium Quality
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full text-[#4B302D] text-sm font-semibold shadow-lg">
                Luxury Accessible
              </div>
            </div>

            {/* Secondary Showcase */}
            <div className="grid grid-cols-2 gap-4">
              <div className="relative aspect-square bg-white/15 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                <div className="relative w-full h-full rounded-lg overflow-hidden">
                  <Image
                    src="https://cdn.abacus.ai/images/315ab5a4-b721-4815-8504-68e4ec742b40.png"
                    alt="Classic craftsmanship detail"
                    fill
                    className="object-cover hover:scale-105 transition-transform duration-500"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
              </div>
              <div className="relative aspect-square bg-white/15 backdrop-blur-sm rounded-xl p-4 shadow-lg">
                <div className="relative w-full h-full rounded-lg overflow-hidden">
                  <Image
                    src="https://cdn.abacus.ai/images/8b79729d-e184-4713-af4c-eca727c9f4d4.png"
                    alt="Precision engineering showcase"
                    fill
                    className="object-cover hover:scale-105 transition-transform duration-500"
                    sizes="(max-width: 768px) 50vw, 25vw"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
