
'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { ChevronDown, Watch, Star, Shield } from 'lucide-react'
import { ShaderBackground } from '@/components/animations/shader-background'
import { GooeyText } from '@/components/animations/gooey-text'
import { RainbowButton } from '@/components/ui/rainbow-button'
import { BackgroundPaths } from '@/components/animations/background-paths'
import Link from 'next/link'

export function HeroSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  const stats = [
    { icon: Watch, label: 'Premium Timepieces', value: '30+' },
    { icon: Star, label: 'Customer Rating', value: '4.9/5' },
    { icon: Shield, label: 'Year Warranty', value: '2' }
  ]

  return (
    <ShaderBackground className="relative min-h-screen flex flex-col overflow-hidden bg-gradient-to-br from-[#F5E6CA] via-[#D6B79E] to-[#BD6A5C]">
      <BackgroundPaths className="absolute inset-0 opacity-30" />
      
      {/* Main Content Container - takes most of the screen */}
      <div className="flex-1 flex items-center justify-center py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            ref={ref}
            initial={{ opacity: 0, y: 50 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="space-y-8 sm:space-y-12"
          >
            {/* Main Heading with Gooey Animation */}
            <div className="space-y-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-6xl sm:text-7xl lg:text-8xl font-bold text-[#4B302D]"
              >
                <GooeyText 
                  text="Luxury Reimagined"
                  className="block mb-2"
                />
              </motion.div>
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 1 } : {}}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-xl sm:text-2xl text-[#4B302D]/80 max-w-3xl mx-auto leading-relaxed"
              >
                Discover precision-engineered timepieces where Japanese craftsmanship meets modern luxury design
              </motion.p>
            </div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="grid grid-cols-3 gap-8 max-w-2xl mx-auto"
            >
              {stats.map((stat, index) => (
                <div key={stat.label} className="text-center">
                  <div className="inline-flex items-center justify-center w-12 h-12 bg-white/20 rounded-full mb-2">
                    <stat.icon className="w-6 h-6 text-[#4B302D]" />
                  </div>
                  <div className="text-2xl font-bold text-[#4B302D]">{stat.value}</div>
                  <div className="text-sm text-[#4B302D]/70">{stat.label}</div>
                </div>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4"
            >
              <Link href="/collections">
                <RainbowButton variant="primary" className="w-full sm:w-auto">
                  Explore Collections
                </RainbowButton>
              </Link>
              
              <Link href="/shop">
                <RainbowButton variant="secondary" className="w-full sm:w-auto bg-white/20 backdrop-blur-sm text-[#4B302D] hover:bg-white/30">
                  Shop All Watches
                </RainbowButton>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator - Fixed at bottom with proper spacing */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ duration: 0.8, delay: 1.0 }}
        className="relative z-10 flex justify-center pb-8 pt-4"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center text-[#4B302D]/60"
        >
          <span className="text-sm mb-2">Scroll to explore</span>
          <ChevronDown className="w-5 h-5" />
        </motion.div>
      </motion.div>
    </ShaderBackground>
  )
}
