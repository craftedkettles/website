
'use client'

import { motion } from 'framer-motion'
import { Instagram, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

export function InstagramFeed() {
  const instagramPosts = [
    {
      id: '1',
      image: 'https://cdn.abacus.ai/images/8b79729d-e184-4713-af4c-eca727c9f4d4.png',
      alt: 'SeikoJust Classic White on Instagram'
    },
    {
      id: '2', 
      image: 'https://cdn.abacus.ai/images/be2747e1-c8a7-4e08-bbdd-f6f80872e9fe.png',
      alt: 'Santos Rose Gold Collection on Instagram'
    },
    {
      id: '3',
      image: 'https://cdn.abacus.ai/images/bd739875-93a0-4420-9ee5-4ff7beacb36e.png',
      alt: 'SeikoNaut Blue Dial on Instagram'
    },
    {
      id: '4',
      image: 'https://neoluxwatch.com/cdn/shop/files/seiko-nautilus-mod-rose-gold-blue-182708.png',
      alt: 'Rose Gold Luxury Watch on Instagram'
    },
    {
      id: '5',
      image: 'https://cdn.abacus.ai/images/315ab5a4-b721-4815-8504-68e4ec742b40.png',
      alt: 'Pink Dial Professional Shot on Instagram'
    },
    {
      id: '6',
      image: 'https://cdn.abacus.ai/images/c71bc13e-79fb-4450-8b4c-c52b199503a1.png',
      alt: 'Midnight Black Watch on Instagram'
    }
  ]

  return (
    <section className="py-20 bg-gradient-to-br from-[#D6B79E]/30 to-[#F5E6CA]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Instagram className="w-8 h-8 text-[#BD6A5C]" />
            <h2 className="text-4xl font-bold text-[#4B302D]">
              Follow Our Journey
            </h2>
          </div>
          <p className="text-xl text-[#4B302D]/70 max-w-2xl mx-auto mb-8">
            Join our community of luxury watch enthusiasts on Instagram and TikTok for daily inspiration and exclusive previews
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://instagram.com/craftedkettles"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block"
            >
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
                <Instagram className="w-5 h-5 mr-2" />
                @craftedkettles
              </Button>
            </a>
            
            <a
              href="https://tiktok.com/@craftedkettles"
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block"
            >
              <Button variant="outline" className="border-[#BD6A5C] text-[#BD6A5C] hover:bg-[#BD6A5C] hover:text-white">
                <TrendingUp className="w-5 h-5 mr-2" />
                TikTok @craftedkettles
              </Button>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {instagramPosts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative aspect-square rounded-lg overflow-hidden group cursor-pointer"
            >
              <Image
                src={post.image}
                alt={post.alt}
                fill
                className="object-cover group-hover:scale-110 transition-transform duration-300"
                sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 16vw"
              />
              
              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center">
                <Instagram className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-8">
          <p className="text-[#4B302D]/60">
            Tag us in your photos with <span className="font-semibold text-[#BD6A5C]">#craftedkettles</span> for a chance to be featured
          </p>
        </div>
      </div>
    </section>
  )
}
