
'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Mail, Send, Gift } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

export function NewsletterSignup() {
  const [email, setEmail] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email) {
      toast.error('Please enter your email address')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      })

      if (response.ok) {
        setIsSubscribed(true)
        setEmail('')
        toast.success('Welcome to our community! Check your inbox for exclusive offers.')
      } else {
        const error = await response.json()
        toast.error(error.message || 'Failed to subscribe. Please try again.')
      }
    } catch (error) {
      toast.error('Failed to subscribe. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  if (isSubscribed) {
    return (
      <section className="py-20 bg-gradient-to-r from-[#4B302D] to-[#BD6A5C]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto">
              <Gift className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white">
              Welcome to the Crafted Kettles Community!
            </h2>
            <p className="text-white/90 text-lg">
              Thank you for subscribing. You'll receive exclusive offers, new collection previews, and luxury watch insights.
            </p>
          </motion.div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 bg-gradient-to-r from-[#4B302D] to-[#BD6A5C]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-8"
        >
          <div className="space-y-4">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-4xl font-bold text-white">
              Join the Inner Circle
            </h2>
            <p className="text-white/90 text-xl max-w-2xl mx-auto">
              Be the first to discover new collections, exclusive offers, and insider insights from the world of luxury timepieces
            </p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-md mx-auto">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="relative">
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pr-12 bg-white/90 border-none text-[#4B302D] placeholder:text-[#4B302D]/60"
                  disabled={isLoading}
                />
                <Mail className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#4B302D]/40" />
              </div>
              
              <Button
                type="submit"
                className="w-full bg-white text-[#BD6A5C] hover:bg-white/90 font-semibold"
                disabled={isLoading}
              >
                {isLoading ? (
                  'Subscribing...'
                ) : (
                  <>
                    Subscribe Now
                    <Send className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </form>

            <p className="text-white/70 text-sm mt-4">
              Exclusive offers • New arrivals • Watch insights • Unsubscribe anytime
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center max-w-2xl mx-auto">
            <div>
              <div className="text-2xl font-bold text-white">10%</div>
              <div className="text-white/80 text-sm">Welcome Discount</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">24h</div>
              <div className="text-white/80 text-sm">Early Access</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-white">VIP</div>
              <div className="text-white/80 text-sm">Member Benefits</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
